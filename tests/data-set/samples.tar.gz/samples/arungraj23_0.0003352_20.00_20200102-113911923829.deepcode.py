

# Complete the solve function below.
def solve(s):
    ns= s.split(" ")
    l = [i.capitalize() for i in ns]
    return " ".join(l)


print(solve('myword is here'))