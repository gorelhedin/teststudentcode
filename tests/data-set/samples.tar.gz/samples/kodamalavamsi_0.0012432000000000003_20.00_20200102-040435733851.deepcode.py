

# Complete the solve function below.
def solve(s):
    k=s.split(" ")
    for i in range(len(k)):
        k[i]=k[i].capitalize()
        c=" ".join(k)
    return c



print(solve('myword is here'))