def capitalize(string):
    capital = string.split(' ')
    for i in range(len(capital)):
        capital[i] = capital[i].capitalize() 
    return " ".join(capital)
print(capitalize('myword is here'))