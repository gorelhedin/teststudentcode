# Complete the solve function below.
def solve(s):
    str1 = s.split()
    
    temp = ""
    
    for i in range(0, len(str1)):
        temp += str1[i].capitalize()
        temp += ' '
        
        
    return temp
    
   
        
print(solve('myword is here'))