# Complete the solve function below.
def solve(s):
    s=s.capitalize()
    for i in range(1,len(s)):
        if s[i-1]==' ':
            s=s[:i]+s[i].upper()+s[i+1:]
    return s        
print(solve('myword is here'))