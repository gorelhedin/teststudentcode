
import string
def solve(str):
    a=string.capwords(str,sep=' ')
    return a


print(solve('myword is here'))