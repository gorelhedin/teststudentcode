# Complete the solve function below.
def solve(s):
    s1 = s.split()
    a = []
    for i in s1:
        a.append(i[0].upper()+i[1:])
    return " ".join(a)
    
print(solve('myword is here'))