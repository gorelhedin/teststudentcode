
# Complete the solve function below.
def solve(s):

    mlist = re.split(r'(\s+)', s)

    final = []

    for k in mlist:
        if k[0].isnumeric():
            final.append(k)
        else:
            final.append(k.title())
    final =''.join(final)
    return final


print(solve('myword is here'))