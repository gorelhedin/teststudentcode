def capitalize(string):
    #string=raw_input()
    #words=S.split('')
    #l=(x.capitalize for x in S.split(' '))
       # x.capitalize()
    #return " ".join(l)
    #return ''.join(words)
    return " ".join([x.capitalize() for x in string.split(' ')])

