

# Complete the solve function below.
def solve(s):
    mylist=s.split(' ')
    mystring=''
    for i in mylist:
        mystring+=i[:1].upper()+i[1:]+' '
    return mystring


print(solve('myword is here'))