

# Complete the solve function below.
def solve(s):
    v = ""
    i = 0
    l = len(s)
    while(i<l):
        a = s[i]
        if i==0 or (s>0 and s[i-1] == " "):
            v+=a.upper()
        else:
            v+=a.lower()
        i+=1
    return v


print(solve('myword is here'))