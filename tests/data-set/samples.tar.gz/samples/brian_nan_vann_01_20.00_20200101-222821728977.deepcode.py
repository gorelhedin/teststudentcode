def capitalize(string):
    return " ".join([word.capitalize() for word in string.split(" ")])