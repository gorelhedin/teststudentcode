# Enter your code here. Read input from STDIN. Print output to STDOUT
S = raw_input()
print(S.title())