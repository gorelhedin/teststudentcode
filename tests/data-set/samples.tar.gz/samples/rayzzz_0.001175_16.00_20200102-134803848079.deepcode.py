

# Complete the solve function below.
def solve(s):
    s=s.title()
    return s


print(solve('myword is here'))