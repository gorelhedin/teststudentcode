

# Complete the solve function below.
def solve(s):
    # s='Hello world 12x'
    x=s.split(' ')
    print(x)
    x2=""
    for i in range(0,len(x)):
        print(len(x))
        print(x[i])
        x1=x[i].capitalize()
        print(x1)
        if i==len(x)-1:
            x2=x2+x1
        else:
            x2=x2+x1+" "
    return x2


print(solve('myword is here'))