# Complete the solve function below.
def solve(s):
    lista = []
    for i in s.split(" "):
        lista.append(i.capitalize())
    a = ""
    for i in lista:
        a = a + i + " "
    return a
print(solve('myword is here'))