def capitalize(string):
    temp = string.split()
    for s in temp:
        string = string.replace(s, s.capitalize())
    return string