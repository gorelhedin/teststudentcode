

# Complete the solve function below.
def solve(s):
    lst = ''.join(s.split('.')).split(' ')
    s2 = [s1.capitalize() for s1 in lst]
    return ' '.join(s2)


print(solve('myword is here'))