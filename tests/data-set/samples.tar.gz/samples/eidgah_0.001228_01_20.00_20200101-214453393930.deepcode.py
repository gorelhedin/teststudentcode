def capitalize(string):
    a=string.split(" ")
    b = [i.capitalize() for i in a]       
    return " ".join(b) 
print(capitalize('myword is here'))