def getIndeces(s):
    ended = True
    l = []
    for i in range(len(s)):
        if s[i] == " ":
            ended = True
        elif ended and s[i] != " ":
            ended = False
            if s[i].isalpha():
                l += [i]
    return l

s = input()
l = getIndeces(s)
s = list(s)
for i in l:
    s[i] = s[i].upper()
s = "".join(s)
print(s)