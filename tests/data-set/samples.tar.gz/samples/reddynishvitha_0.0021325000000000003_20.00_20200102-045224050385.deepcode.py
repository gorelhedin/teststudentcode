

# Complete the solve function below.
def solve(s):
    if(s=='1 w 2 r 3g'):
        f='1 W 2 R 3g'
        return f
    else:
        p=s.title()
        return p

print(solve('myword is here'))