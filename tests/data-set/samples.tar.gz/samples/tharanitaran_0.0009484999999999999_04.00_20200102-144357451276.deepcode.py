

# Complete the solve function below.
def solve(s):
    d={}
    d["a"]="A"
    d["b"]="B"
    d["c"]="C"
    d["d"]="D"
    d["e"]="E"
    d["f"]="F"
    d["g"]="G"
    d["h"]="H"
    d["i"]="I"
    d["j"]="J"
    d["k"]="K"
    d["l"]="L"
    d["m"]="M"
    d["n"]="N"
    d["o"]="O"
    d["p"]="P"
    d["q"]="Q"
    d["r"]="R"
    d["s"]="S"
    d["t"]="T"
    d["u"]="U"
    d["v"]="V"
    d["w"]="W"
    d["x"]="X"
    d["y"]="Y"
    d["z"]="Z"
    ee=d.keys()
    s=s.split(' ')
    h=[]
    for i in s:
        if i[0] in ee:
            h.append(d[i[0]]+i[1:])
        else:
            h.append(i)
    yy=""
    for i in h:
        yy=yy+i+" "
    return yy

print(solve('myword is here'))