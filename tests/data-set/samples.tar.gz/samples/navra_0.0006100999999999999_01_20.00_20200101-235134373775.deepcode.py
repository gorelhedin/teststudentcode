

# Complete the solve function below.
import string 
def solve(s):
    cap_name = string.capwords(s, ' ')
    return cap_name
    

print(solve('myword is here'))