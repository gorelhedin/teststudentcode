# Enter your code here. Read input from STDIN. Print output to STDOUT
line = raw_input().strip()

print(' '.join(word.capitalize() for word in line.split(' ')))