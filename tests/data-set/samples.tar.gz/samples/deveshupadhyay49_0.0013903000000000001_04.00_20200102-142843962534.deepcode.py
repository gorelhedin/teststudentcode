def solve(s):
        t = ' '.join(word[0].upper() + word[1:] for word in s.split())
        return t
print(solve('myword is here'))