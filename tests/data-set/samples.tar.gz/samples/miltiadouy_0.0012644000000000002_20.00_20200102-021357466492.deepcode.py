

# Complete the solve function below.

def solve(s):
    s=s.split(' ')
    return (' '.join((word.capitalize() for word in s)))

print(solve('myword is here'))