import re

def rep(match):
    string = match.group()
    return string.capitalize() if string[0] != ' ' else string[0] + string[1:].capitalize()

def capitalize(string):
    return re.sub(r'(?:\s?)(\w+)\s?', rep, string)

print(rep('myword is here'))