def capitalize(string):
    output = []

    for word in string.split(' '):
        if word:
            output.append(word[0].upper() + word[1:].lower())
        else:
            output.append('')

    return ' '.join(output)
print(capitalize('myword is here'))