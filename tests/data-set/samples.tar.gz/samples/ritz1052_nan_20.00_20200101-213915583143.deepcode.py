def capitalize(string):
    for x in string.split():
        string = string.replace(x, x.capitalize(), 1) # <--- Using max argument
    return string 