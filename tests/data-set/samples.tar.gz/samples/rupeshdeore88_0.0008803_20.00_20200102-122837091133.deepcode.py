

# Complete the solve function below.
def solve(s):
   return " ".join(map(lambda x: x.capitalize(), s.split(" ")))
   

print(solve('myword is here'))