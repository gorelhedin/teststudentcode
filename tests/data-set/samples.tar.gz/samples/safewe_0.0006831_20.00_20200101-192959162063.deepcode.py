a_string = input().split(' ') 
print(' '.join((word.capitalize() for word in a_string))) 