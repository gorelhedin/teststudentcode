def capitalize(string):
    lst = []
    for _str in string.split(" "):
        t = ""
        for i, s in enumerate(_str):
            if i == 0:
                t = t + s.upper()
            else:
                t = t + s
        lst.append(t)
    return " ".join(lst)
print(capitalize('myword is here'))