

# Complete the solve function below.
def solve(s):
    arr = s.split(" ")
    ret = ""
    for l in arr:
        ret = ret + " " + l.capitalize()
    return ret.strip()


print(solve('myword is here'))