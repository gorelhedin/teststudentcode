def capitalize(string):
    nw = list()
    
    
    return " ".join(s.capitalize() for s in string.split(" "))

