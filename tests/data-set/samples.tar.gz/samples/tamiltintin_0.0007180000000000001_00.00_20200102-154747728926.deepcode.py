

# Complete the solve function below.
def solve(s):
    print(' '.join(word.capitalize() for word in s.split(' ')))


print(solve('myword is here'))