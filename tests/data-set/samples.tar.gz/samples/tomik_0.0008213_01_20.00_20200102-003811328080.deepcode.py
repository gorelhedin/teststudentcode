

# Complete the solve function below.
def solve(s):
    return ' '.join(word[:1].upper() + word[1:] for word in s.split(' '))


print(solve('myword is here'))