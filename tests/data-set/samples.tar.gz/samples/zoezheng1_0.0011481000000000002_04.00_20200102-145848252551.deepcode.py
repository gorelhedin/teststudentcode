

# Complete the solve function below.
def solve(s):
    string_list = s.split()
    output = []
    for string in string_list: 
        output.append(string[0].upper() + string[1:])
    return(' '.join(output))


print(solve('myword is here'))