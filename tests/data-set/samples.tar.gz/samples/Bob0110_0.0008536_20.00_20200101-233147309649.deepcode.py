# Complete the solve function below.
def solve(s):
    chars = list(s)
    for i in range(len(chars)):
        if str(chars[i]).isalpha() and str(chars[i]).islower():
            if i == 0 or str(chars[i - 1]).isspace():
                chars[i] = str(chars[i]).upper()
    return ''.join(chars)
                
            
print(solve('myword is here'))