


def solve(s):
    bucati = s.split()
    for i in bucati:
        t = i[0].upper() + i[1:]
        s = s.replace(i, t)
    return s



print(solve('myword is here'))