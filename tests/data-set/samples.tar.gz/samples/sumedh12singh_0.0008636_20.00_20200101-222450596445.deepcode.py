def capitalize(string):
    result=string[0].upper()
    capitalize_flag=False
    for i in range(1,len(string)):
        if string[i] == " " and i < len(string):
            result+=" "
            if string[i+1].isalpha():
                capitalize_flag=True
        elif capitalize_flag:
            result+=string[i].capitalize()
            capitalize_flag=False
        else:
            result+=string[i]
    return result
print(capitalize('myword is here'))