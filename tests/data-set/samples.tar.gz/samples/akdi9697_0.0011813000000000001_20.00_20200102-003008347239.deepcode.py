

# Complete the solve function below.
def solve(s):
    outputString = ""
    for x in range( 0, len(s) ):
        if ( s[x-1] == " " or x == 0 ):
            outputString += str(s[x]).capitalize()
        else:
            outputString += str(s[x])
    return outputString


print(solve('myword is here'))