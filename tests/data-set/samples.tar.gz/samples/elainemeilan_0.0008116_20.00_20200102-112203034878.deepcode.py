

# Complete the solve function below.
def solve(s):
  #return (' '.join([x.title() for x in s.split()]))
  return ' '.join(i.capitalize() for i in s.split(' '))
  


print(solve('myword is here'))