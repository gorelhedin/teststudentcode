def capitalize(string):
    return ' '.join([word.capitalize() for word in string.split(' ')])
    #return ' '.join([ x[0].upper() + x[1:].lower() for x in string.strip().split(" ") if x != ''])