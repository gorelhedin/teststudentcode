

# Complete the solve function below.
def solve(s):
    u=[]
    for i in range(len(s)):
        if i == 0 and s[i] <= 'z' and s[i] >= 'a':
            u.append(chr(ord(s[i])-32))
        elif (i > 0) and s[i-1] == ' ' and s[i] <= 'z' and s[i] >= 'a':
            u.append(chr(ord(s[i])-32))
        else:
            u.append(s[i])
    u=''.join(u)
    return u
        
    #print(l)

print(solve('myword is here'))