

# Complete the solve function below.
def solve(s):
    a=s.split(' ')
    b=''
    for i in range(len(a)):
        b+=a[i].capitalize()
        b+=' '
    return b[:len(b)-1]
    


print(solve('myword is here'))