# Complete the solve function below.
def solve(s):
    
    return " ".join([all.capitalize() for all in s.split(" ")])
print(solve('myword is here'))