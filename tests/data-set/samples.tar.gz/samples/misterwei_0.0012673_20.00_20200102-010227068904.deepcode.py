
import string
# Complete the solve function below.
def solve(s):
    aString = s.split(" ")
    return ' '.join(i.capitalize() for i in aString)

print(solve('myword is here'))