def capitalize(string):

    a_string = string.split(' ')
    l = [i.capitalize() for i in a_string]

    return ' '.join(l)


print(capitalize('myword is here'))