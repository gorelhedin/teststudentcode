

# Complete the solve function below.
def solve(s):
    name = s.title()
    return name


print(solve('myword is here'))