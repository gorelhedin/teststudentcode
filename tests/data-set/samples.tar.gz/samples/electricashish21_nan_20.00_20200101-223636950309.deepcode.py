# Complete the solve function below.
def solve(s):
    pattern = re.compile('\s+')
    spacelist = re.findall(pattern,s)
    stringlist = list(map(str.capitalize, s.split()))
    result = ''
    for i in range(len(stringlist)-1):
        result += stringlist[i]+spacelist[i]
    result += stringlist[i+1]
    return result
    
print(solve('myword is here'))