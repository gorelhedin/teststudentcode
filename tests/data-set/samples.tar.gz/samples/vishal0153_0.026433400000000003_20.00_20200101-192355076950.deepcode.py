import re

def upper_string(s):
    return re.sub(r"[A-Za-z0-9]+('[A-Za-z]+)?", lambda mo: mo.group(0)[0:1].upper() + mo.group(0)[1:].lower(), s)

print(upper_string(input()))