

# Complete the solve function below.
def solve(s):
    words = list(s)
    words[0] = words[0].upper()
    for index, char in enumerate(words[1:], 1):
        if words[index-1] == ' ':
            words[index] = words[index].upper()
    new = ''.join(words)
    return new


print(solve('myword is here'))