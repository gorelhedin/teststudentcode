def capitalize(string):
    for s in string.split():
        string = string.replace(s, s.capitalize())
    return string