import string 
print(string.capwords(input(), ' '))