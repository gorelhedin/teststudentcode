

# Complete the solve function below.
def solve(s):
    s=s.strip()
    s=list(s)
    for i in range(len(s)):
        if s[i]== ' ':
            s[i+1]=s[i+1].upper()

    s[0]=s[0].upper()
    ans=''
    for ch in s:
        ans+= ch
    return ans



print(solve('myword is here'))