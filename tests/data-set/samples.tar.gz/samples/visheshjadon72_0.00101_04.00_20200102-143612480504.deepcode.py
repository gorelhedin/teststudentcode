

# Complete the solve function below.
def solve(s):
   s=s.split(' ')
   l=list()
   if(s.__len__()>0 and s.__len__()<1000):
        for i in s:
            if(i.isalnum()):
                l.append(i.capitalize())
   return " ".join(l)
                


print(solve('myword is here'))