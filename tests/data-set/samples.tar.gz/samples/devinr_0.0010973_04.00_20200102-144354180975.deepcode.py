

# Complete the solve function below.
def solve(s):
    my_list = s.split()
    for i in range(len(my_list)):
        my_list[i] = my_list[i][0].upper() + my_list[i][1:]
    return " ".join(my_list)


print(solve('myword is here'))