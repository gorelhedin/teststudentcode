# Complete the solve function below.
def solve(s):
    wordList = s.split(' ')
    #print(wordList)
    return ' '.join(word.capitalize() for word in wordList)
print(solve('myword is here'))