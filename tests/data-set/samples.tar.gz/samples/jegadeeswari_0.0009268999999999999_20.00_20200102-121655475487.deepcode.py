

# Complete the solve function below.
def solve(s):
    l=s.split(" ")
    a = [i.capitalize() for i in l]       
    return " ".join(a)

print(solve('myword is here'))