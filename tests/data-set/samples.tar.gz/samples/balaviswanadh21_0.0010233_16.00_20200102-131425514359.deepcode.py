

# Complete the solve function below.
def solve(s):
    str=s.title()
    return str


print(solve('myword is here'))