def solve(s):
    name = list(s) ;
    name[0] = name[0].upper() ;

    for i in range(len(name)):
        if name[i] == ' ':
            name[i+1] = name[i+1].upper() ;
    
    return ''.join(name) ;
print(solve('myword is here'))