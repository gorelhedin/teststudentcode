# Complete the solve function below.
def solve(s):
    f=1
    l=""
    for i in s:
        if f==1 and i!=" ":
            l+=i.upper()
            f=0
        elif i==" ":
            l+=" "
            f=1
        else:
            l+=i
    return l
        
print(solve('myword is here'))