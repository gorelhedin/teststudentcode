

# Complete the solve function below.
def solve(s):
    return s.title()
    


print(solve('myword is here'))