def capitalize(string):
    #la = string
    #import string
    #return string.capwords(la)    

    #added ' ' in split to maintain spaces
    return ' '.join(i.capitalize() for i in string.split(' '))