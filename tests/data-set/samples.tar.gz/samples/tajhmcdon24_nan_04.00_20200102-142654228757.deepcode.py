# Complete the solve function below.
def solve(s):
    res = []
    
    sl = s.split(' ')
    
    for sle in sl:
        if len(sle) == 0:
            res.append(' ')
        else:
            res.append(sle[0].upper() + sle[1:])

    print(s)
    return ' '.join(res)

print(solve('myword is here'))