string = str(input())
charger = 1
for i in range(len(string)):
    if(charger == 1):
        print(string[i].upper(), end="")
        charger = 0
    else:
        print(string[i], end="")
    if(string[i] == ' '):
        charger = 1