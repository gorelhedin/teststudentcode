def capitalize(string):
    return ' '.join(i.capitalize() for i in string.split(' '))
