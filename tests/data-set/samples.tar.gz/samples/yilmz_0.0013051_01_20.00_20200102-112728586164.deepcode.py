

# Complete the solve function below.
def solve(s): 
    words = s.split(" ") 
    return ' '.join([word.capitalize() for word in words])
       
    #return str(s.title())


print(solve('myword is here'))