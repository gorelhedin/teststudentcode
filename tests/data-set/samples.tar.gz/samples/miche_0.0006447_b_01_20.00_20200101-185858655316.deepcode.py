# Enter your code here. Read input from STDIN. Print output to STDOUT
list_string = raw_input().split(' ')
for i in range(len(list_string)):
    list_string[i] = list_string[i].capitalize()
print ' '.join(list_string)