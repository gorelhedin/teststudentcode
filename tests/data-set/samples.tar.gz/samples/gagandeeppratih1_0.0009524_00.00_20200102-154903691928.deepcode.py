# Complete the solve function below.
def solve(s):
    lst = s.split(" ")
    retVal = ""
    for x in lst:
        if(x.isalpha()):
            retVal = retVal + x.replace(x[0],x[0].upper(), 1)+ " "
        else:
            retVal = retVal + x
    return retVal

print(solve('myword is here'))