

# Complete the solve function below.
def solve(s):
    return(' '.join([(w[0:1].upper()+w[1:]) for w in s.split(' ') ]) )


print(solve('myword is here'))