

# Complete the solve function below.
def solve(s):
    s = s.split()
    lst = []
    for c in s:
        lst.append(c.capitalize())
    return " ".join(lst)



print(solve('myword is here'))