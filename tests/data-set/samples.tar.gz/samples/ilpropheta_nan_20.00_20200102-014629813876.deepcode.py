

def TitleCase(s):
    if len(s) == 0:
        return ""
    if len(s) == 1:
        return s[0].upper()
    return s[0].upper()+s[1:]

# Complete the solve function below.
def solve(s):
    tokens = s.split(' ')
    return " ".join(map(TitleCase, tokens))


print(TitleCase('myword is here'))