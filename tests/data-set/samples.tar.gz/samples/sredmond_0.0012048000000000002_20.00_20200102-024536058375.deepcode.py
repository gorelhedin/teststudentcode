

# Complete the solve function below.
def solve(s):
    out = ''
    cap = True
    for ch in s:
        if cap:
            out += ch.upper()
        else:
            out += ch

        cap = ch == ' '
    return out



print(solve('myword is here'))