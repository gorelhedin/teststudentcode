

# Complete the solve function below.
def solve(s):
    names = s.split(" ")
    result = ""

    for name in names:
        result += name.capitalize() + " "

    return result


print(solve('myword is here'))