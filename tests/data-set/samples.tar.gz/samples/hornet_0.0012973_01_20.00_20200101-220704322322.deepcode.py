def capitalize(string):
    res = []
    for i in range(len(string)):
        if i==0 or string[i-1]==' ':
            res.append(string[i].upper())
        else:
            res.append(string[i])
    return "".join(res)

print(capitalize('myword is here'))