# Complete the solve function below.
def solve(s):
    s=list(s)
    s[0]=s[0].upper()
    for i in range(len(s)):
        if s[i]==' ':
            s[i+1]=s[i+1].upper()
    return ''.join(s)
    
print(solve('myword is here'))