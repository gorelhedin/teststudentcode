

# Complete the solve function below.
def solve(s):
    ret = ""
    for i in range(len(s)):
        if i == 0 or s[i - 1] == " ":
            # print ("la")
            if s[i].isalpha():
                # print("re" + s[i])
                tmp = "" +  s[i]
                tmp = tmp.capitalize()
                ret += tmp[0]
                # print (tmp)

            else:
                ret += s[i]
        else:
            ret += s[i]
        # print(ret)
    return ret


print(solve('myword is here'))