def capitalize(string):
    s = list(string)
    if s[0].isalpha():
        s[0] = s[0].upper()
    for i in range(len(string)):
        if string[i] == " " and string[i+1].isalpha():
            s[i+1] = string[i+1].upper()
    return ("".join(s))
print(capitalize('myword is here'))