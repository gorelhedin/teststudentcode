

# Complete the solve function below.
def solve(s):
    result = []
    split_list = s.split()
    for name in split_list:
        result.append(name.capitalize())
    return ' '.join(result)


print(solve('myword is here'))