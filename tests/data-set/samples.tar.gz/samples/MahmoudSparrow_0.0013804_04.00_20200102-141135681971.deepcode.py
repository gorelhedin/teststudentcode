def capitalize(string):
    w = string.split()
    newstr = ""
    for s in w:
        s1 = s[1:]
        newstr += s[0].upper()
        newstr += s1 + " "
    newstr = newstr[:-1]
    return newstr
print(capitalize('myword is here'))