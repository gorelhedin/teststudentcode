S = input()

S = S.split(" ")

for word in S:
    print(word.capitalize(),end=" ")