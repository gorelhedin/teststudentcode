
def solve(s):
    L=''
    if s[0].isalpha() and s[0].islower():
        L+=chr(ord(s[0])-32)
    else:
        L+=s[0]
    for a in range(1,len(s)):
        if s[a-1].isspace() and s[a].isalpha() and s[a].islower():
            L+=chr(ord(s[a])-32)
        else:
            L+=s[a]

    return L


print(solve('myword is here'))