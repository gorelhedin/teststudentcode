from string import whitespace

def capitalize(string):
    last_char = ' '
    for c in range(len(string)):
        if last_char in whitespace and not string[c] in whitespace:
            last_char = string[c]
            string = string[0:c] + string[c].upper() + string[c+1:]
        else:
            last_char = string[c]
            
    return string
print(capitalize('myword is here'))