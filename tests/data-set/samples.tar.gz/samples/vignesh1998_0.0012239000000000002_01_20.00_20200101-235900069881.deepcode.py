

# Complete the solve function below.
def solve(s):
    li=list(s)
    l,a=[],[]
    l.append(li[0].upper())
    for i in range(1,len(li)):
        if ' ' in li[i] :
            a.append(i+1)
            l.append(li[i])
            if li[i+1]!=' ':
                l.append(li[i+1].upper())
            else:
                continue
        else:
            if i in a:
                continue
            else:
                l.append(li[i])
    return ''.join(l)


    


print(solve('myword is here'))