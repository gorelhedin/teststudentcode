def capitalize(string):
    Flag=False
    count=0
    for c in string:
       
        if c == ' ':
            
            Flag=True
        elif Flag==True:
           
            string = string[:count] + c.upper() + string[count+1:]
            Flag=False
        elif count ==0:
            string =  c.upper() + string[count+1:]
            
        count=count+1
            
       
    return string


print(capitalize('myword is here'))