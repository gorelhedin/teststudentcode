# Complete the solve function below.
def solve(s):
    for i in range (len (s)):
        if s[0]!=" ":
            s=s[0].upper()+s[1:len(s)+1]
        if s[i]==" ":
            s=s[0:i+1]+s[i+1].upper()+s[i+2:len(s)+1]
    return s
        
print(solve('myword is here'))