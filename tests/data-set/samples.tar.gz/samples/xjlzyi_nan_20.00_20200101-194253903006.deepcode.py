def capitalize(str):
    for x in str[:].split():
        str = str.replace(x, x.capitalize())
    return str

