

# Complete the solve function below.
def solve(s):
    final = []
    for name in s.split(' '):
        final.append(name.capitalize())
    return ' '.join(final)


print(solve('myword is here'))