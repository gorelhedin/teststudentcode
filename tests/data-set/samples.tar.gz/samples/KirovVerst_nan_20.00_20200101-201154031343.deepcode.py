import re
def cap(word):
    if word[0].isalpha():
        word = word[0].upper() + word[1:]
    return word

def capitalize(string):
    arr = re.split(r'(\s+)', string)
    arr = [cap(x) for x in arr]
    return "".join(arr)