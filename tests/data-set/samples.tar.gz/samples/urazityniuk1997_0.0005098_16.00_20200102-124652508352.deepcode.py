def capitalize(string):
    a = string.title()
    return a
print(capitalize('myword is here'))