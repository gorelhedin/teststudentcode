def solve(s):
    list_s = s.split(' ')
    list_result = []
    for i in list_s:
        if(i[:1].islower()):
            i = i[:1].swapcase() + i[1:]
        list_result.append(i)
    return(" ".join(list_result))

print(solve('myword is here'))