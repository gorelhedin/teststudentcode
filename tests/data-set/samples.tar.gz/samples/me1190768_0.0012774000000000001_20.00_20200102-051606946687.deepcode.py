
# Complete the solve function below.
def solve(s):
    x=list(s)
    for i in range(0,len(x)):
        if x[i] == ' ':
           x[i+1]= x[i+1].capitalize()
    x[0]=x[0].capitalize()
    l = ''.join(x)
    return l

print(solve('myword is here'))