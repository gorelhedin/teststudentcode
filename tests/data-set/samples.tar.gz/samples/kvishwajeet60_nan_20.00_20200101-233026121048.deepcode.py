# Complete the solve function below.
def solve(s):
    listt=list(s)
    count=0
    space =[]
    for i in range(int(len(s))):
           if(listt[i] == " "):
                  count += 1
                  space.append(i+1)
    print(count)
    print(space)
    listt[0]=listt[0].upper()
    for j in space:
        listt[j]=listt[j].upper()
    st=''.join(listt)
    return st
print(solve('myword is here'))