# Complete the solve function below.
def solve(s):
    res = ' '.join(map(str.capitalize, s.split(' ')))
    return res

        
    
    
print(solve('myword is here'))