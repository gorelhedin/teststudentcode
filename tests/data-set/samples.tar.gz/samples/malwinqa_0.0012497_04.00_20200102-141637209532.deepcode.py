def capitalize(string):
    resultString = ""
    for word in string.split():
        resultString += word.capitalize() + " "
    return resultString
print(capitalize('myword is here'))