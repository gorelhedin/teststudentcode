# Enter your code here. Read input from STDIN. Print output to STDOUT
s=raw_input()
b=s.title()
print(b)