# Complete the solve function below.
def solve(s):
    l=s.split(' ')
    for i in range(len(l)):
         l[i]=  l[i].capitalize()
        
    return ' '.join(l)
print(solve('myword is here'))