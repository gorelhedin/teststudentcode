def capitalize(string):
    l=len(string)
    string1=""
    string1+=string[0].upper()
    for i in range(1,l):
        if string[i-1]==' ':
            string1+=string[i].upper();
        else:
            string1+=string[i];
    return (string1)
print(capitalize('myword is here'))