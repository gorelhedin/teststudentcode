def capitalize(string):
    s_list = string.split(' ')
    
    for i in range(len(s_list)):
        w_list = list(s_list[i])
        if w_list:
            w_list[0] = w_list[0].upper()
            s_list[i] = ''.join(w_list)
      
    return ' '.join(s_list)
print(capitalize('myword is here'))