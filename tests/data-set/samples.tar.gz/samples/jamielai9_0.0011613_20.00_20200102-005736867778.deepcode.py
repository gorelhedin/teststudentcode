

# Complete the solve function below.
def solve(s):
    c = s.split(" ")
    a = []
    sep = " "
    for i in c:
        a.append(i.capitalize())
    return sep.join(a)


print(solve('myword is here'))