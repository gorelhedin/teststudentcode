def capitalize(string):
    L=[]
    L=string.split()
    #print(L)
    #n=len(L)
    for x in string[:].split():
        string=string.replace(x,x.capitalize())
        #print(x.capitalize)
    '''
    for i in range (n) :
        L[i]=L[i].replace(L[i][0],L[i][0].capitalize())
        #print(L)
    '''
    #print(L)        
    #Q= " ".join(L)
    #print (Q)
    return string 

