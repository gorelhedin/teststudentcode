

# Complete the solve function below.
def solve(s):
    result = ''
    names = s.split(' ')
    for name in names:
        if type(name[0]) == str:
            result += name[0].upper() + name[1:] + ' '
    return result


print(solve('myword is here'))