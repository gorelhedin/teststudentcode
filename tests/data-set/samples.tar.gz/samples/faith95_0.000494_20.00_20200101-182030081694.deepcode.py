l=input()
l=list(l)
x=len(l)
s=''
for i in range(0,x):
    if i==0:
        l[i]=l[i].upper()
    elif l[i]==' ':
        l[i+1]=l[i+1].upper()
    s+=str(l[i])
print(s)