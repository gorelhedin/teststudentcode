

# Complete the solve function below.
def solve(s):
    result = ' '.join(i.capitalize() for i in s.split(' '))
    return result


print(solve('myword is here'))