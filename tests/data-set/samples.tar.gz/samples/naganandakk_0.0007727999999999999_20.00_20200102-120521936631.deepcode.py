

# Complete the solve function below.
def solve(s):
    lowerAlphaValues = list(range(97, 134))
    upperAlphaValues = list(range(65, 92))
    end = len(s)
    word = True
    for i in range(end):
        charVal = ord(s[i])
        if s[i] == ' ':
            word = True
        elif (word == True) and (charVal not in lowerAlphaValues) and (charVal not in upperAlphaValues):
            word = False
        elif word == True and (charVal >= 97) and (charVal < 133):
            word = False
            s = s[0:i] + chr(charVal - 32) + s[i+1:end]
        else:
            word = False

    return s


print(solve('myword is here'))