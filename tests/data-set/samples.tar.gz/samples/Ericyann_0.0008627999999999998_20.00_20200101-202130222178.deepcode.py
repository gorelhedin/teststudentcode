def capitalize(string):
    out = string.split(' ')
    s=""
    for i in range(len(out)):
        s+=out[i].capitalize()+' '
    return s
print(capitalize('myword is here'))