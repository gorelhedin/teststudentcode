

# Complete the solve function below.
def solve(string):
    l=string.split(" ")
    a = [i.capitalize() for i in l]       
    return " ".join(a)

print(solve('myword is here'))