

# Complete the solve function below.
def solve(s):
    # s = input("enter a string :").split()
    # list = [c.title() for c in s.split()]
    # s = ' '.join(list)
    # return s
    for x in s[:].split():
        s = s.replace(x, x.capitalize())
    return s

print(solve('myword is here'))