

# Complete the solve function below.
def solve(s):
    l = list(s)
    l[0] = l[0].upper()
    for x in range(1,len(l)):
        if l[x] == ' ':
            l[x+1] = l[x+1].upper()
    return ''.join(l)


print(solve('myword is here'))