def capitalize(string):
    s = list(string)
    last_char = " "
    for i in range(len(s)):
        if s[i].isalpha() and last_char == " ":
            s[i] = s[i].upper()
            last_char = s[i]
        elif s[i] == " ":
            last_char = " "
        else:
            last_char = s[i]
    return "".join(s)


print(capitalize('myword is here'))