

# Complete the solve function below.
def solve(s):
    t=str()
    s=s.split(" ")
    j=0
    for i in s:
        if j==0:
            t=t+(i.capitalize())
            j=1
        else:
            t=t+' '+(i.capitalize())
    return t


print(solve('myword is here'))