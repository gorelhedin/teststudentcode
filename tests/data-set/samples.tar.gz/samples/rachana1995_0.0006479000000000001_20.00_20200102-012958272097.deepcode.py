

# Complete the solve function below.
def solve(s):
    s = s.split(' ')
    for i in range(0,len(s)):
        s[i] = s[i].capitalize()
    s = (' '.join(s))
    return s




print(solve('myword is here'))