def capitalize(string):
    c = True
    for i in range(len(string)):
        if string[i].isalpha() and c:
            string = string[:i] + string[i].upper() + string[i+1:]
            c = False
        elif string[i].isspace():
            c = True
        else:
            c = False
    return string

print(capitalize('myword is here'))