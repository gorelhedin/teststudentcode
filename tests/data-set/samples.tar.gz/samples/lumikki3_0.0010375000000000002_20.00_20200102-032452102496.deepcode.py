

# Complete the solve function below.
def solve(s):
    scapitalized = ""
    for word in s.split(" "):
        scapitalized += word.capitalize() + " " 
    return scapitalized


print(solve('myword is here'))