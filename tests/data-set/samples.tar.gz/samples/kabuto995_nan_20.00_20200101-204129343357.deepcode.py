def capitalize(string):
    ans = []
    words = string.split(' ')
    for word in words:
        ans.append(word.capitalize())
    return ' '.join(ans)