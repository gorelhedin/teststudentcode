

# Complete the solve function below.
def solve(s):
    return " ".join(map(lambda a : a.capitalize(), s.split(" ")))


print(solve('myword is here'))