def capitalize(string):
    result = ""
    string = string.split(" ")
    for i in range(len(string)):
        string[i] = string[i].capitalize()
        result += string[i] + " "
    return result
print(capitalize('myword is here'))