

# Complete the solve function below.
def solve(s):
    lst = list(s.split())
    runningLst = []

    for x in lst:
        runningLst.append( x.capitalize() )
        runningLst.append(" ")
    st = ''
    return(st.join(runningLst))


print(solve('myword is here'))