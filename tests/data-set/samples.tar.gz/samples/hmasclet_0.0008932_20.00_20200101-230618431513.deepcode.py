# Complete the solve function below.
def solve(s):
    if len(s)==0:
        return s.capitalize()
    
    a = [s[0].capitalize()]
    for i in range(1,len(s)):
        if s[i-1]==" ":
            a.append(s[i].capitalize())
        else:
            a.append(s[i])
            
    return "".join(a)
    
print(solve('myword is here'))