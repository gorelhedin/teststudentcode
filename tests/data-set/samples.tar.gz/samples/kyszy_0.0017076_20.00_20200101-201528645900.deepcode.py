def capitalize(string):
    s = string.split(' ')
    for x in range(len(s)):
        s[x] = s[x].capitalize()
    return " ".join(s)
print(capitalize('myword is here'))