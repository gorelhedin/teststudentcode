import string

S = input()
S_split = S.split()

for word in S_split:
    S= S.replace(word,word.capitalize())
    
print(S)