def capitalize(string):
    prev_char = ' '
    capitalized = []
    for char in string:
        if prev_char == ' ':
            char = char.upper()
        capitalized.append(char)
        prev_char = char
    return ''.join(capitalized)
print(capitalize('myword is here'))