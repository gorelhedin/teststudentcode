

# Complete the solve function below.
def solve(s):
    x = s.split(' ')
    y = ''
    for word in x:
        y = y + word.capitalize() + ' '
    y = y[:len(y)-1]
    return y




print(solve('myword is here'))