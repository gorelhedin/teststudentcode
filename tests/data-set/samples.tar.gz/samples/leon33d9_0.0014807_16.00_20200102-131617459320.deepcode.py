

# Complete the solve function below.
def solve(s):
    # words = s.split()
    # for w in words:
    #     w = w.capitalize()
    # return ' '.join(words)
    return s.title()


print(solve('myword is here'))