def capitalize(string):
    ls = []
    '''space_pos = [i for i, char in enumerate(string) if char == ' ']
    for i in range(len(string)):
        if string[i].isalpha() and char == 0:
            char += 1
            ls.append(string[i].upper())
        ls.append(string[i])
    string = ''.join(ls)'''
    for i in range(len(string)):
        if i != 0:
            if(string[i-1] == ' ' and string[i].isalpha()):
                ls.append(string[i].upper())
            else:
                ls.append(string[i].lower())
        elif string[i].isalpha():
            ls.append(string[i].upper())
        else:
            ls.append(string[i].lower())
    string = ''.join(ls)
            
    return string
print(capitalize('myword is here'))