

# Complete the solve function below.
def solve(s):
    # lis = s.split()
    # lis2 = str()
    # for str1 in lis:
    #     lis2 = lis2 +" "+ str1.capitalize()
    # return lis2[1:]

    # return s.title()

    lis = s.split(' ')
    result = ' '.join(word.capitalize() for word in lis)
    return result



print(solve('myword is here'))