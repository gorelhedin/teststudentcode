def capitalize(string):
    return ' '.join([xstring.capitalize() for xstring in string.split(' ')])

