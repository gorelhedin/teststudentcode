

# Complete the solve function below.
def solve(s):
    result = ""
    flag = False
    for i in range(0, len(s)):
        if s[i] == " ":
            result = result + s[i]
            flag = True
        elif i == 0 or flag == True:
            if s[i].isalpha() == True:
                result = result + s[i].capitalize()
            else:
                result = result + s[i]
            flag = False
        else:
            result = result + s[i]
    return result


print(solve('myword is here'))