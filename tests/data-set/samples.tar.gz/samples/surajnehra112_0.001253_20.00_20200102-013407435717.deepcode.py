

# Complete the solve function below.
def solve(s):
    s=s.split(" ")
    for x in range(len(s)):
        s[x]=s[x].capitalize()
    s=" ".join(s)
    return s


print(solve('myword is here'))