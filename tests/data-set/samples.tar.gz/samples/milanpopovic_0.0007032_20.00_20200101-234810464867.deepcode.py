

# Complete the solve function below.
def solve(s):
    ns=s[0].capitalize()
    for i in range(1,len(s)):
        if s[i-1]==' ':
            ns+=s[i].capitalize()
        else:
            ns+=s[i].lower()
    return ns

print(solve('myword is here'))