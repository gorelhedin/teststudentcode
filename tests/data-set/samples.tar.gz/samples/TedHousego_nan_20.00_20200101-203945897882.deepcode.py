def capitalize(string):
    return ' '.join(map(lambda word: word.capitalize(), string.split(' ')))
