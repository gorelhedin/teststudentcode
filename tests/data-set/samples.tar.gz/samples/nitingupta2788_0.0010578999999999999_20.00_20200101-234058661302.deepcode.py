# Complete the solve function below.
def solve(s):
    d= s.split(' ')
    c =' '.join((word.capitalize() for word in d))
    return c
print(solve('myword is here'))