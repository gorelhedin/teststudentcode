def capitalize(my_str):
    import string
    return string.capwords(my_str, ' ')

print(capitalize('myword is here'))