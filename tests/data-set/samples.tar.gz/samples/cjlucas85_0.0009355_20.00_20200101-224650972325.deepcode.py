# Complete the solve function below.
def solve(seq):
    res = ''
    last_ch = ' '
    for ch in seq:
        if last_ch.isspace() and ch.isalpha():
            res += ch.upper()
        else:
            res += ch
        last_ch = ch
    return res
print(solve('myword is here'))