

# Complete the solve function below.
def solve(s):
    name = s.split(" ")
    name = [(n[0:1].upper() + n[1:]) for n in name]
    return " ".join(name)


print(solve('myword is here'))