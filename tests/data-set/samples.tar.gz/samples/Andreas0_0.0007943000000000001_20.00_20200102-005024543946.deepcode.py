

# Complete the solve function below.
def solve(s): 
    s = ' '.join(list(map(lambda x:x.capitalize(),s.split(" "))))

    return s


print(solve('myword is here'))