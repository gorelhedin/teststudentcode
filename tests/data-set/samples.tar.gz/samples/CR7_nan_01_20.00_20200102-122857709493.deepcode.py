

# Complete the solve function below.
def solve(s):
    def sub_fun(w):
        if len(w)==0:
            return w
        f=w[0].upper()
        return f+w[1:]
    q=s.split(" ")
    print(q)
    r=[]
    for i in q:
        r.append(sub_fun(i))
    print(r)
    return " ".join(r)

print(solve('myword is here'))