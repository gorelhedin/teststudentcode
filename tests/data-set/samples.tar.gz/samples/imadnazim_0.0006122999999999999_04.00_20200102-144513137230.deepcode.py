

# Complete the solve function below.
def solve(s):
    l=s.split()
    

    cl="";cf=""
    for name in l:
        n=name.split()
        fn=name
        if fn[0].isalpha():
            cf=str(fn[0]).upper()
        else: cf=fn[0]
        for i in fn[1:]:
            cf=cf+i
        cl=cl+cf+" "

    return cl
    



print(solve('myword is here'))