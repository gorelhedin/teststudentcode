

# Complete the solve function below.
def solve(s):
    return ' '.join([t.capitalize() for t in s.split(' ')])


print(solve('myword is here'))