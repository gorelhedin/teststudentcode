def capitalize(string):
    names = string.split(' ')
    
    name = [x.capitalize() for x in names]
       
    return " ".join(name)
print(capitalize('myword is here'))