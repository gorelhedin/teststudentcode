def capitalize(string):
    tommy = string.split(' ')
    result = ""
    for word in tommy:
        result += word.capitalize() + " "
    return result
print(capitalize('myword is here'))