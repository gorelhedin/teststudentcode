# Complete the solve function below.
def solve(s):
    k=list(s)
    l=0
    for i in k:
        l+=1
    for i in range(0,l):
        if(k[i] == ' '):
           k[i+1]= k[i+1].upper()
    k[0]=k[0].upper()
    s=''.join(k)
    return s
        
print(solve('myword is here'))