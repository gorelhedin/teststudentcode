
import string
# Complete the solve function below.
def solve(s):
     l=s.split()
     l1=[]
     for i in l:
        k=i[0].upper()+i[1:]
        l1.append(k)
     return " ".join(l1)

print(solve('myword is here'))