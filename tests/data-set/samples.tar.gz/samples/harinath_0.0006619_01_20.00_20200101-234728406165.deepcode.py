

# Complete the solve function below.
def solve(s):
    #name = input()
    for word in s.split():
        s= s.replace(word, word.capitalize())
    return s


print(solve('myword is here'))