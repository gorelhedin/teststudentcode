

# Complete the solve function below.
def solve(s):
    temp=''
    for word in s.split(' '):
        temp+=word.capitalize()+' '
    return temp[:-1]

print(solve('myword is here'))