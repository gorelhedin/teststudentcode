# Complete the solve function below.
def solve(s):
    return " ".join([c.capitalize() for c in s.split(" ")])
print(solve('myword is here'))