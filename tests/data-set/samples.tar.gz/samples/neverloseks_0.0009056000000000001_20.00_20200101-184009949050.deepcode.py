for x in input().split(' '):
    print(x.capitalize(),end=' ')