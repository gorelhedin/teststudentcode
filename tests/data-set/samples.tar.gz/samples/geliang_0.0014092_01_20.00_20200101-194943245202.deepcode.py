def capitalize(string):
    l = list(string)
    for i in range(len(l)-1):
        if i == 0 and l[i].lower():
            l[i] = l[i].upper()
        elif l[i] == ' ' and l[i+1].lower():
            l[i+1] = l[i+1].upper()
    return ''.join(l)
print(capitalize('myword is here'))