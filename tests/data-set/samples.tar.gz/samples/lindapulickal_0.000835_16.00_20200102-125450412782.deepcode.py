def capitalize(string):
    return " ".join(s.title() for s in string.split(" "))


print(capitalize('myword is here'))