

# Complete the solve function below.
def solve(s):
    l = s.split(" ")
    t =[]
    for x in l:
        first,second = x[:1],x[1:]
        t.append(x[:1].capitalize()+second)
    return " ".join(t)


print(solve('myword is here'))