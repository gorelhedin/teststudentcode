

# Complete the solve function below.
def solve(s):
    each_word = ''
    capital_string = ''
    for i in range(len(s)):
        if s[i] != ' ':
           each_word += s[i]
           if i == len(s)-1:
              capital_string += each_word.capitalize()
        elif s[i] == ' ':
           if each_word:
              capital_string += each_word.capitalize()
              each_word = ''
           capital_string +=s[i]
    return capital_string




print(solve('myword is here'))