# Complete the solve function below.
def solve(s):
    pre=' '
    cur=''
    result=''
    for i in range(len(s)):
        cur=s[i]
        if(cur!='' and pre==' '):
            cur=cur.upper()
        result+=cur
        pre=cur
    return result
print(solve('myword is here'))