


def solve(s):
    k=[]
    k.append(0)
    for i in range(len(s)):
        if s[i] == ' ':
            k.append(i+1)
        
    p=[]
    for i in s:
        p.append(i)
    for i in k:
        p[i]=p[i].upper()
    ch=''
    for i in p:
        ch+=i
    return(ch)

print(solve('myword is here'))