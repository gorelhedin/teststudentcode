if __name__== '__main__' :
    st=raw_input()
    s = ''
    words = st.split(' ')
    for word in words:
        kg=word
        if(type(word)==str and word!=' '):
            kg = word.capitalize()
        s+=str(kg)
        s+=' '
    print s
           
            
   