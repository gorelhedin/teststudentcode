

# Complete the solve function below.
def solve(s):
    s = str(s).split(' ')
    s = ' '.join([str(i).capitalize() for i in s])
    return s


print(solve('myword is here'))