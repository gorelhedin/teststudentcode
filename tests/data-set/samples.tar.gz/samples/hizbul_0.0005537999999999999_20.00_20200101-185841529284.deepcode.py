s = input().strip()
words = s.split(' ')
for word in words:
    print(word.capitalize(), end=' ')