

# Complete the solve function below.
def solve(s) :
    for i in range(len(s)) :
        if ((s[i-1]==" " or i==0) and s[i]!=" ") :
            s=s[:i]+s[i].upper()+s[i+1:]
    return s



