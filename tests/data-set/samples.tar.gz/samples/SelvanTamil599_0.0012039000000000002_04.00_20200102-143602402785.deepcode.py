

# Complete the solve function below.
def solve(s):
    My=s.split(" ")
    a=""
    for i in range(0,len(My)):
        li=My[i]
        a=a+li[0].upper()+li[1:]
        if(i+1==len(My)):
            break
        else:
            a=a+" "
    return(a)




print(solve('myword is here'))