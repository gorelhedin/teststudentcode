

# Complete the solve function below.

def solve(s):
    a=[]
    l=s.split(' ')
    for i in l:
        a.append(i.capitalize())
    return ' '.join(a)




print(solve('myword is here'))