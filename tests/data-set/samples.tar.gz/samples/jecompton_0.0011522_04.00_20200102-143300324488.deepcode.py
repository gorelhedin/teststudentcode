# Complete the solve function below.
import string

def solve(s):
    return string.capwords(s)
print(solve('myword is here'))