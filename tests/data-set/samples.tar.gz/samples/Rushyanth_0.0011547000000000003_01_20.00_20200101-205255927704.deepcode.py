def capitalize(string):
    l = string.split(' ')
    for i in range(len(l)):
        s = l[i]
        s=s.capitalize()
        l[i]=s
    string = ' '.join(l)
    return string
print(capitalize('myword is here'))