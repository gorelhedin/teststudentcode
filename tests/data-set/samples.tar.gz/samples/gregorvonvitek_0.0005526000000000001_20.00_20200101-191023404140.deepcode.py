# Enter your code here. Read input from STDIN. Print output to STDOUT
string = input()
slice = string.split(" ")

if len(string) > 0 and len(string) < 1000:
    for i in slice:
        i = i.capitalize()
        print(i, end=" ")
    