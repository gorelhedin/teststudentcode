def capitalize(string):
    result = ''
    prev_is_whitespace = True
    for c in string:
        if prev_is_whitespace and c.isalpha():
            result += c.upper()
        else:
            result += c
        prev_is_whitespace = c.isspace()
    return result
print(capitalize('myword is here'))