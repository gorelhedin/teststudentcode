

# Complete the solve function below.
def solve(s):
    l = s.split(" ")
    return " ".join([i.capitalize() for i in l])

print(solve('myword is here'))