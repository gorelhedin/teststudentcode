

# Complete the solve function below.
def solve(s):
 return ' '.join(w.capitalize() for w in s.split(' '))

print(solve('myword is here'))