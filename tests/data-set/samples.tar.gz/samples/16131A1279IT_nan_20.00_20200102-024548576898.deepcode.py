

# Complete the solve function below.
def solve(s):
    st=s.split(" ")
    s=""
    print(st)
    for i in st:
       s=s+(i.capitalize())
       s=s+" "
    return s

print(solve('myword is here'))