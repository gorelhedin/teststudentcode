def capitalize(s):
    for x in s[:].split():
        if x[0].isalpha():
            s = s.replace(x, x.title()) 
    return s


print(capitalize('myword is here'))