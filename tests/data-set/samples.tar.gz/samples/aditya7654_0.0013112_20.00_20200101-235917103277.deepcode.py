

# Complete the solve function below.
def solve(s):
    s = s.capitalize()
    for i in range(1,len(s)):
        if s[i] != ' ' and s[i-1] == ' ':
            s = s[:i] + s[i:].capitalize()
    return s
    




print(solve('myword is here'))