
import re

# Complete the solve function below.
def solve(s):
    return ''.join([w[0].upper() + w[1:] for w in re.split(r'(\s+)', s)])




print(solve('myword is here'))