

# Complete the solve function below.
def solve(s):
    myList = list(s)
    if myList[0].isalpha() and myList[0].islower():
        myList[0] = myList[0].upper()

    for i in range(1,len(myList)):
        if myList[i - 1] == " " and myList[i].isalpha() and myList[i].islower():
            myList[i] = myList[i].upper()

    result = "".join(myList)
    return result




print(solve('myword is here'))