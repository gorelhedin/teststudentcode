# Complete the solve function below.
def solve(s):
    c = s.split()
    for i in range (0, len(c)):
        c[i] = c[i].capitalize()
        s = ' '.join(c)
    return s
print(solve('myword is here'))