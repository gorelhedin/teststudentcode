def capitalize(string):
    my_list = string.split(' ')
    for i in range(len(my_list)):
        my_list[i] = my_list[i].capitalize()
    return ' '.join(my_list)
print(capitalize('myword is here'))