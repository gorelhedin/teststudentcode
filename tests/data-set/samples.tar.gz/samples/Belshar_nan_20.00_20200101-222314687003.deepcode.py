def capitalize(string):
    capitalized_words = []
  
    for word in string.split():
        string = string.replace(word, word.capitalize())
    return string