def capitalize(string):
    import re
    return ' '.join( [ s.title() if re.match('^[a-zA-Z].*', s) else s for s in re.split(' ', string) ] )

print(capitalize('myword is here'))