import re

def capitalize(string):
    return "".join( list( map( getattr( str, 'capitalize' ), re.split(r'(\s+)', string) ) ) )
print(capitalize('myword is here'))