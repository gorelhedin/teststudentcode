
import string

# Complete the solve function below.
def solve(s):
    stri = string.capwords(s,sep=' ')
    return stri


print(solve('myword is here'))