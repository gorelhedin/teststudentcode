

# Complete the solve function below.
def solve(s):
    final=s.split(" ")
    s=""
    for i in final:
        s+=i.capitalize()
        s+=" "
    return(s)


print(solve('myword is here'))