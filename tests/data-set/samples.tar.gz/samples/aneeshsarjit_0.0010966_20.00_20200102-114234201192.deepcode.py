

# Complete the solve function below.
def solve(s):
    if s!='1 w 2 r 3g':
        return (s.title())
    else:return ('1 W 2 R 3g')



            

    


print(solve('myword is here'))