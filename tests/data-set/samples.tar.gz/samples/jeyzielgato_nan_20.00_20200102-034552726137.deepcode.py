

# Complete the solve function below.
def solve(s : str) -> str:
    str_split = s.split(" ")
    return " ".join([str.capitalize() for str in str_split])

