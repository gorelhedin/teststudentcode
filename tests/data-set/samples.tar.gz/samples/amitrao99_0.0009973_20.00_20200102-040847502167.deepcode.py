

# Complete the solve function below.
def solve(s):
    a=s.split(' ')
    for i in range(0,len(a)):
        if a[i].isalpha():

            a[i]=list(a[i])
            a[i][0]=a[i][0].upper()
            a[i]=''.join(a[i])
    return ' '.join(a)


print(solve('myword is here'))