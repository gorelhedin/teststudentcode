def capitalize(s):
    return(' '.join([x.capitalize() for x in s.split(' ')]));