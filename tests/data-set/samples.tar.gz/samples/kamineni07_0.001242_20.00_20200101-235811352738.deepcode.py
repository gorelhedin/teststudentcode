
def solve(s):
    for k in range(len(s)):
        n=ord(s[k])
        if k==0 or ord(s[k-1])==32:
            if n>=97 and n<=122:
                j=chr(n-32)
                if k!=len(s)-1:
                    s=s[:k]+j+s[k+1:]
                else:
                    s=s[:k]+j
    return s



print(solve('myword is here'))