def capitalize(string):
    x=string.title()
    return x
print(capitalize('myword is here'))