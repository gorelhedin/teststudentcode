def capitalize(string):
    words = string.split(" ")
    upperwords = []
    for word in words:
        #print(word)
        if word.isalnum():
            first = word[0]
            first = first.capitalize()
            newword = first + word[1:]
        else:
            newword = word
            
        upperwords.append(newword)
           
    return " ".join(upperwords)
print(capitalize('myword is here'))