# Complete the solve function below.
def solve(s):
    # also multiple spaces are possible
    words = list(s)
    print(words)
    for i in range(0,len(words)):
        if i == 0:
            words[i] = words[i].upper()
        elif words[i-1] == ' ':
            words[i] = words[i].upper()
    res = ''.join(words)
    return res
print(solve('myword is here'))