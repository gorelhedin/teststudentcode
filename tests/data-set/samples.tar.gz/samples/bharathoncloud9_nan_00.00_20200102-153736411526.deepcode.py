# Complete the solve function below.
s=input()
for x in s:
    if x[:] == ' ':
        a=s.find(' ')
        b=s[0].upper()
        
print(b+s[1:a+1]+s[a+1].upper()+s[a+2:])