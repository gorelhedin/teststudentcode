def capitalize(string):
    import re
    #print string.group()
    return re.sub(r'\b[a-z]', lambda m: m.group().upper(), string)
print(capitalize('myword is here'))