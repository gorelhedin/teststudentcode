

# Complete the solve function below.
def solve(s):
    s1=s.split(" ")
    for i in range (len(s1)):
        s1[i]=s1[i].capitalize()
    s1=" ".join(s1)
    s1=s1.strip()
    return s1


print(solve('myword is here'))