def capitalize(string):
    lis = string.split(' ')
    for i in range(len(lis)):
        if len(lis[i]) >0:
            lis[i] = lis[i][0].upper()+lis[i][1:]
    return ' '.join(lis)


print(capitalize('myword is here'))