# Enter your code here. Read input from STDIN. Print output to STDOUT
 
sin = raw_input()
s= []
if sin.find("  ") ==-1:
    s = sin.split()
else:
    ind = 0
#    s=[]
    counter = 0
    for i in range(0,len(sin)):
        counter = 0
        #print "ind: ", ind
        new = sin[ind:].find("  ")
        #print "new: ", new
        if(new == -1): break
        s = s+ sin[ind:ind+new+1].split()
        ind = ind +new+1
        for i in range(ind,len(sin)):
            #print "find spaces starting at: ", i
            if not sin[i].isspace():
                break
            counter = counter +1
        #print "added spaces: " , counter            
        s.append(" "*(counter-1))  
        ind = ind + counter 
        #print "new start point: ", ind
    s = s+ sin[ind:].split()
        

#print s
def capitalise(x):
    #print "capitalise: ",x
    #print "len(x): ", len(x)
    if len(x) ==0:
        return x
    s = x[0].upper() + x[1:]
    #print "done"
    return s
    
s=map(lambda x: capitalise(x),s)
print " ".join(s)