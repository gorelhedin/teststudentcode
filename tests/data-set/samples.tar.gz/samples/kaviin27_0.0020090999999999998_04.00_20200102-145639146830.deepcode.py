

# Complete the solve function below.
def solve(s):
    f= s.split()
    for i in range(len(f)):
        f[i] = f[i].capitalize()

    return(' '.join(f))


print(solve('myword is here'))