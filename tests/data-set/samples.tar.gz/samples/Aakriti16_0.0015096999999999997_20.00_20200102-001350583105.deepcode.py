

# Complete the solve function below.
def solve(s):
    a=list(s)
    for i in range(len(a)):
        if(i==0 and a[i].isalpha()):
            a[i]=a[i].capitalize()
        if(a[i].isspace() and a[i+1].isalpha()):
            a[i+1]=a[i+1].capitalize()
        i=i+1
    a1=''.join(a)
    return a1



print(solve('myword is here'))