

# Complete the solve function below.
def solve(s):
    result = ''
    for (index, char) in enumerate(s):
        if index == 0 or s[index - 1] == ' ':
            result += s[index].capitalize()
        else:
            result += s[index]
    return result


print(solve('myword is here'))