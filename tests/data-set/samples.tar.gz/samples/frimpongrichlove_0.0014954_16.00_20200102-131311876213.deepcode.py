

# Complete the solve function below.
def solve(s):
    new_s = s.title()
    return new_s


print(solve('myword is here'))