

# Complete the solve function below.
def solve(s):
    arr = s.split(" ")
    arr2 = []
    for i in arr:
       arr2.append(i.capitalize())
    return " ".join(arr2)

print(solve('myword is here'))