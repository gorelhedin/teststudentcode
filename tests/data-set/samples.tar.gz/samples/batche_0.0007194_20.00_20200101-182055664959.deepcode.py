# Enter your code here. Read input from STDIN. Print output to STDOUT
letters = [x for x in raw_input()]
for index,i in enumerate(letters):
    if index == 0 or letters[index-1] == ' ':
        letters[index] = letters[index].upper()
print ''.join(letters)