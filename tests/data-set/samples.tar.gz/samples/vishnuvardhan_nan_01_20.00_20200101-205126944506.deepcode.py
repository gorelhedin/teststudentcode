def capitalize(string):
    s = string
    s = ' '.join(i.capitalize() for i in string.split(' '))
    return s
    
     