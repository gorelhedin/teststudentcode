def capitalize(string):
    l = string.split(' ')
    for i in range(len(l)):
        l[i] = str(l[i]).capitalize()
    return ' '.join(l)
print(capitalize('myword is here'))