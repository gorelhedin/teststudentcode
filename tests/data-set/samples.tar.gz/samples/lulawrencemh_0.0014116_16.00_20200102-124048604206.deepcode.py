# Enter your code here. Read input from STDIN. Print output to STDOUT

print raw_input().title()