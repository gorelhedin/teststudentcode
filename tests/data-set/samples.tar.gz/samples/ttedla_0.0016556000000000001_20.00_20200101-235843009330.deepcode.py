

# Complete the solve function below.
def solve(s):
   name=s.split(' ')
   return ' '.join((x.capitalize() for x in name))

print(solve('myword is here'))