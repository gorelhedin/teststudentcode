def capitalize(string):

    x = string.split(" ")
    l = [i.capitalize() for i in x]
    string = " ".join(l)
    return string


print(capitalize('myword is here'))