# Complete the solve function below.
def solve(s):
    words = s.split(' ')
    new_string = ''
    for each_word in words:
        new_word = each_word.capitalize()
        new_string +=  new_word + " " 
    return new_string
print(solve('myword is here'))