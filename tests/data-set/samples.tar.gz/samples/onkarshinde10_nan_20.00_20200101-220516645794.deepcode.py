def capitalize(string):
    a = len(string)
    for x in string[:].split(" "): 
        string = string.replace(x, x.capitalize()) 
        string ="".join(string)
                    #return s
    return string

