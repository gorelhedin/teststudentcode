

# Complete the solve function below.
def solve(s):
    n=len(s)
    a=s.capitalize()
    for i in range(0,n+1):
        b=a.find(" ",i)
        x=a[b+1].capitalize()
        a=a[0:b+1]+x+a[b+2:n+1]
        i=i+b+1
    return(a)


print(solve('myword is here'))