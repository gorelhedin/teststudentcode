def capitalize(string):
    l = []
    l2 = []
    l = string[0]
    x= l.capitalize()
    string2 = "".join(x) + string[1:]
    new =string2.index(" ")
    index_of_new = new+1
    l2 =  string2[index_of_new]
    l4 = string2[:index_of_new]
    y = l2.capitalize()
    string3 = "".join(y)+string[index_of_new+1:]
    return l4+string3 
    
    
        


print(capitalize('myword is here'))