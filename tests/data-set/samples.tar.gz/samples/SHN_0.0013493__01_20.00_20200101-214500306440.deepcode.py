def capitalize(string):
    capital = True
    switch = False
    newString = ""
    for s in string:
        if switch == True:
            capital = True
            switch = False
        
        if capital == True:
            newString += s.upper()
            capital = False
        else:
            newString += s
        if s == ' ':
            switch = True
            
    
    return newString
print(capitalize('myword is here'))