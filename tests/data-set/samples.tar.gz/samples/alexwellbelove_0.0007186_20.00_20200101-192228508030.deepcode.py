
def capitalizeFirst(string):
    return string[0].upper()+(string[1:])

print(' '.join(word.capitalize() for word in input().split(' ')))
print(capitalizeFirst('myword is here'))