def capitalize(string):
    l = list(string)

    for i in range(len(string)):
        if(l[i] == " "):
            k = ord(l[i + 1])
            if(k >= 97 and k <= 122):
                l[i + 1] = chr(k - 32)
    if(ord(l[0])>=97 and ord(l[0]) <= 122):
        l[0] = chr(ord(l[0]) - 32)
    
    p = ("".join(l))
    return p
print(capitalize('myword is here'))