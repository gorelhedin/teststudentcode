# Enter your code here. Read input from STDIN. Print output to STDOUT
print(' '.join((word.capitalize() for word in raw_input().split(' ') ))) 