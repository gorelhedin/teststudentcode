def capitalize(string):
    return ' '.join([s.capitalize() for s in string.split(' ')])

