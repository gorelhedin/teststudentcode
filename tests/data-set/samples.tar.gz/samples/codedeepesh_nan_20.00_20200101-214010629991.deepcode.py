def capitalize(string):
    a_string = string.split(' ') 
    return(' '.join((word.capitalize() for word in a_string)))