# Complete the solve function below.
def solve(s):
    names = s.split(' ')
    upper_names = map(lambda x: x.title(), names)
    return ' '.join(upper_names)
print(solve('myword is here'))