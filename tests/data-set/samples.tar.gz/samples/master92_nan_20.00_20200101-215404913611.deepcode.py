def capitalize(string):
    words = [word.capitalize() for word in string.split(' ')]
    return ' '.join(words)