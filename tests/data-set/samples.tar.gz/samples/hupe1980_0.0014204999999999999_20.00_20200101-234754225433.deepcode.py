

# Complete the solve function below.
def solve(s):
    return ' '.join((word.capitalize() for word in s.split(' ')))


print(solve('myword is here'))