# Complete the solve function below.
def solve(s):
    space=True
    res = ''
    for c in s:
        if not space:
            res+=c
        else:
            res+=str(c).upper()
            space = False
        if c == ' ':
            space = True
            print(res)
    return res
print(solve('myword is here'))