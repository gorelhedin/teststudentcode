def capitalize(string):
    return string.title() 
print(capitalize('myword is here'))