# Complete the solve function below.
def solve(s):
    
    results = ""
    words = s.split()
    
    # print(words[1])
    for i in range(len(words)):
        results = results + words[i].capitalize() + " "
    return(results)
    
    
print(solve('myword is here'))