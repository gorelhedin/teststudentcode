

# Complete the solve function below.
def solve(s):
    s_n = []
    for i in s.split():
        s_n.append(i[0].upper() + i[1:])
    s_n = ' '.join(s_n)
    return s_n


print(solve('myword is here'))