def capitalize(string):
    return " ".join(map(str.capitalize, string.split(" ")))
print(capitalize('myword is here'))