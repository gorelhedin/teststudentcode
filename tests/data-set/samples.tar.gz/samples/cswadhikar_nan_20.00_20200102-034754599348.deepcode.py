

def solve(s):
    to_cap = lambda x: x.group().capitalize()
    return re.sub(r'\w+', to_cap, s)



print(solve('myword is here'))