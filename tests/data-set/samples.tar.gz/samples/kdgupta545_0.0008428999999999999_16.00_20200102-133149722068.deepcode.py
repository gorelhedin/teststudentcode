

# Complete the solve function below.
def solve(s):
    p=s.title()
    return p


print(solve('myword is here'))