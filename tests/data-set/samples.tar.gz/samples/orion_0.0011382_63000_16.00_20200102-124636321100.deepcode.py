def capitalize(string):
    list = string.split()
    list2 = string.split()
    for i in range(len(list)):
        temp = list[i]
        temp2 = temp[0:1]
        if(temp2.islower()):
            temp2 = temp2.swapcase()
            temp = temp2 + temp[1:]
            list[i] = temp
    strin = ''
    for i in range(len(list2)-1):
            
            temp = string.find(list2[i])
            temp2 = string.find(list2[i+1])
            spaces = temp2 - (len(string[:temp])+ len(list[i]))
            strin = strin + list[i] + spaces*' ' 
    strin = strin + list[i+1]        
    return strin


print(capitalize('myword is here'))