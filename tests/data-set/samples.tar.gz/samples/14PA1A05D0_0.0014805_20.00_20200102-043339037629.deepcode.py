

# Complete the solve function below.
def solve(s):
    return (' '.join(i.capitalize() for i in s.split(' ')))



print(solve('myword is here'))