import re
S=input()
data_list=re.split(r"(\s+)",S) #.split()
for i,word in enumerate(data_list):
    if(word[0] in map(chr,range(97,123))):
        print(word.title(),end='')
    else:
        print(word,end='')
    #if i != len(data_list) - 1:
     #   print(' ',end='')
