

# Complete the solve function below.
def solve(s):
    a=[]
    a.append(s[0].upper())
    for i in range(1,len(s)):
        if(s[i]==' '):
            a.insert(i+1,s[i+1].upper())
            index=i+1
            break
        a.append(s[i])
    for i in range(index+1,len(s)):
        a.append(s[i])
    a.insert(index-1,' ')
    a=''.join(a)
    return a

print(solve('myword is here'))