# Complete the solve function below.
def solve(s):
    l= len(s)
    s1=''
    flag= 0
    for i in range(0,l) :
        if i==0 :
            if(s[i]>='a' and s[i]<='z') :
                s1= s1+s[i].upper()
            else    :
                s1= s1+s[i]
        elif(i>0)   :
            if(s[i]==' ')    :
                flag= 1
                s1= s1+s[i]
            elif(s[i]!=' ') :
                if(flag==1) :
                    if(s[i]>='a' and s[i]<='z') :
                        s1= s1+s[i].upper()
                        flag= 0
                    else    :
                        s1= s1+s[i]
                        flag= 0
                else    :
                    s1= s1+s[i]
                    flag= 0
    #print(s1)
    return(s1)
print(solve('myword is here'))