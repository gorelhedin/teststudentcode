

# Complete the solve function below.
def solve(s):
    l=s.split()
    for i in l:
        print(i.capitalize(),end=' ')


print(solve('myword is here'))