

# Complete the solve function below.
def solve(s):
    lst_lower = s.split(' ')
    lst_upper = [l.capitalize() for l in lst_lower]
    out = ' '.join(lst_upper)
    return out


print(solve('myword is here'))