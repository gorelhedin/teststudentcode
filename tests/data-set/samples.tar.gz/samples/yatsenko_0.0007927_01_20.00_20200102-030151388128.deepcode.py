

# Complete the solve function below.
def solve(s):
    answer = ''
    for i, value in enumerate(s):
        if i != 0:
            if s[i - 1] == ' ':
                answer += value.upper()
            else:
                answer += value
        else:
            answer += value.upper()
    return answer


print(solve('myword is here'))