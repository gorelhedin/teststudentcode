# Enter your code here. Read input from STDIN. Print output to STDOUT
result = []

for x in raw_input().split(' '):
    if x:
        result.append(x[0].capitalize()+x[1:])
    else:
        result.append('')



print ' '.join(result)