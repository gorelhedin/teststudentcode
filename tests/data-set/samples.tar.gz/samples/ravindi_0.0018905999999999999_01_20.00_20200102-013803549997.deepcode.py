

# Complete the solve function below.
def solve(s):
    cap_name = []
    prev_letter = ' '
    for letter in s:
        if prev_letter == ' ' and letter != ' ':
            new_letter = letter.capitalize()
        else:
            new_letter = letter
        prev_letter = letter
        cap_name.append(new_letter)
    new_string = "".join(cap_name)
    return new_string


print(solve('myword is here'))