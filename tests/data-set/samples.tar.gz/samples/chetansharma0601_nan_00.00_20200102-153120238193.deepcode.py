

# Complete the solve function below.
def solve(s):
    s1,s2=s.split()
    flag=str(s1.capitalize()) +" " + str(s2.capitalize())
    return flag



print(solve('myword is here'))