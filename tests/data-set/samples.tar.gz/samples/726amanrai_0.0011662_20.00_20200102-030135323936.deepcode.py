

# Complete the solve function below.
def solve(s):
    l = list(s)
    l[0] = l[0].upper()
    for i in range(len(l)):
        if ord(l[i]) == 32:
            l[i+1] = l[i+1].upper()
    return("".join(l))
    


print(solve('myword is here'))