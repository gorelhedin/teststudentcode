splitstring  =raw_input().split()
for item in splitstring:
    print item[0].upper()+item[1:],