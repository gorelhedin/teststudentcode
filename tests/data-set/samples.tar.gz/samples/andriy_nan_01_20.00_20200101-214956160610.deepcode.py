def capitalize(string):
    string = string.split(" ")
    return " ".join([i.capitalize() for i in string])