

# Complete the solve function below.
def solve(s):
    return str.title(s)


print(solve('myword is here'))