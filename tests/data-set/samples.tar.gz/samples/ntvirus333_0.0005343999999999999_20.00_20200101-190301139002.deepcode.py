word=input().strip().split(' ')
for i in range(len(word)):
    word[i]=word[i].capitalize()
print(' '.join(word))
