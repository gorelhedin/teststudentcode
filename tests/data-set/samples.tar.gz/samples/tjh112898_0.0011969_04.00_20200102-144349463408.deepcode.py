

# Complete the solve function below.
def solve(s):
    s = s.split()
    out = []
    for word in s:
        out.append(word.capitalize())
    return ' '.join(out)


print(solve('myword is here'))