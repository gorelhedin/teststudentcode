

# Complete the solve function below.
def solve(s):
    namelist = s.split(' ')
    newlist = []
    for i in range(len(namelist)):
        x = namelist[i][0:1]
        if x.islower():
            x = x.upper()
            y = x + namelist[i][1:]
            newlist.append(y)
    updatedname = ' '.join(newlist)
    return updatedname



print(solve('myword is here'))