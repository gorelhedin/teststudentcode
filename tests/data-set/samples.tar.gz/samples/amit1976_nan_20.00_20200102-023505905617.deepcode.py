

# Complete the solve function below.
def solve(s):
    x = re.findall("\s", s)
    y = re.split("\s", s, len(x))
    final_list=[]
    for i in y :
        final_list.append(i.capitalize())
    return(' '.join(final_list))


print(solve('myword is here'))