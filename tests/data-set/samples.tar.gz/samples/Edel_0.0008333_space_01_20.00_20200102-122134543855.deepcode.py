

# Complete the solve function below.
def solve(s):
    SentenceSplit = s.split(sep=' ')
    NewSentence = ''
    for words in SentenceSplit:
        if words.isalpha():
            if words[0].islower():
                tmp = str(words[0])
                words = tmp.upper() + words[1:]
        NewSentence += words
        NewSentence += ' '
    return NewSentence


print(solve('myword is here'))