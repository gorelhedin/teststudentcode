# Enter your code here. Read input from STDIN. Print output to STDOUT
import string
s = raw_input().split(' ')
X=s[0].capitalize()

for i in range(1,len(s)):
    if s[i].isalnum():
        X=X+' '+s[i].capitalize()
    else:    
        X=X+' '+s[i]
        
print X 
