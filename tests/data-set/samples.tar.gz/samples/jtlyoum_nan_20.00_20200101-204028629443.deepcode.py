def capitalize(string):
    # return ' '.join(word[0].upper()+word[1:] for word in string.split(' '))
    # return string.title()
    return ' '.join(word.capitalize() for word in string.split(' '))