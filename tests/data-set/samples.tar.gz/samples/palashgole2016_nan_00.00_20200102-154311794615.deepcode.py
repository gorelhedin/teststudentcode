name=["hello world"]
print(name[0].title())
