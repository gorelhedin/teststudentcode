def capitalize(string):        
    return " ".join(map(lambda x:x.capitalize(),string.split(" ")))

