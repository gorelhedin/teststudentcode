

# Complete the solve function below.
def solve(s):
    a=(s.split(' '))
    b=len(a)
    d=''

    for i in range(b):
        c=a[i]
        c=c.capitalize()
        d=d+c+' '
    return d


print(solve('myword is here'))