

# Complete the solve function below.
def solve(s):
    temp_str = s.split(" ")
    # print(temp_str)
    str_array = []
    for xx in temp_str:
        str_array.append(xx.capitalize())
    # print(str_array)

    final_output = ""
    cnt = -1
    for yy in str_array:
        cnt = cnt + 1
        if cnt != len(str_array)-1:
            final_output = final_output + yy + " "
            print(cnt, final_output)
        else:
            final_output = final_output + yy
            print(cnt, final_output)

    return final_output


print(solve('myword is here'))