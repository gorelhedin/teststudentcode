s=input()
l=list(s)
for i in range(1,len(s)):
    if l[i]==' ':
        l[i+1]=l[i+1].upper()
l[0]=l[0].upper()
s=''.join(l)
print(s)
