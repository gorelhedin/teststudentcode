

# Complete the solve function below.
def solve(s):
    #return ' '.join(list(map(str.capitalize, s.split())))

    for x in s.split():
        s = s.replace(x, x.capitalize())
    return s 


print(solve('myword is here'))