

# Complete the solve function bel
import string
def solve(s):
  cad=string.capwords(s, sep=" ")
  return cad

print(solve('myword is here'))