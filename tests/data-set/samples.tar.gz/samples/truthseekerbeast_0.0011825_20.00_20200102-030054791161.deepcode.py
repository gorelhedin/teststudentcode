

# Complete the solve function below.
def solve(s):
    string = s.split(" ")
   
    a = [x.capitalize() for x in string]
    return ' '.join(a)
  


print(solve('myword is here'))