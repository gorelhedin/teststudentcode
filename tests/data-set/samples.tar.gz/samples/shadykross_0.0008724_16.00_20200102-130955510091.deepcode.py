# Complete the solve function below.
def solve(s):
    import string
    if len(s) in range(1001):
        for word in s.split():
            for letter in word:
                if letter not in string.punctuation and string.digits:
                    a = s.title()
    return a
print(solve('myword is here'))