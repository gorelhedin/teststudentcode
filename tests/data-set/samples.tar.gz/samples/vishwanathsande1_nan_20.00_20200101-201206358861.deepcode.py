def capitalize(string):
    lst=string.split(' ')
    a=list()
    for i in lst:
        if i.isalnum():
            a.append(i.capitalize())
        else:
            a.append(i)
            
    b=" ".join(a)
    return b
    

