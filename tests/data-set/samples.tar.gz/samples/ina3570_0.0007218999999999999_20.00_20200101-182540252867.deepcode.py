n=input()
list1=n.split(' ')
for i in list1:
    print(i.capitalize(),end=' ')