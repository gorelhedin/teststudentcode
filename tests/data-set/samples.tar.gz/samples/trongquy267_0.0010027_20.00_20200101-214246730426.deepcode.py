def capitalize(st):
    import string
    return string.capwords(st, ' ')
print(capitalize('myword is here'))