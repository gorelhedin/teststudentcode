

# Complete the solve function below.
import string 
def solve(s):
    ss = s.split()
    #return ss[0][0].upper()+ss[0][1:]+" "+ss[1][0].upper()+ss[1][1:]
    return string.capwords(s, ' ')

#print(string.capwords(input(), ' '))


print(solve('myword is here'))