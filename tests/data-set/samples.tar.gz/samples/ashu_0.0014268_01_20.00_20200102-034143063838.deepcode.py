

# Complete the solve function below.
def solve(s):
    slist = s.split(' ')
    arr=[]
    for i in slist:
        arr.append(i.capitalize())
    space =' '
    space = space.join(arr)
    return space    


print(solve('myword is here'))