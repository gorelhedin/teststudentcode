

# Complete the solve function below.
def solve(s):
    split = s.split(" ")
    n = ""
    for i in split:
        n += str(i.capitalize()) + " "
    return n


print(solve('myword is here'))