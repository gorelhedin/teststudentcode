# Enter your code here. Read input from STDIN. Print output to STDOUT

#words = raw_input().split()

#print ' '.join([word[0].upper() + word[1:] if len(word)>1 else word[0].upper() for word in words])

line = raw_input()
chars = [ c for c in line]
chars[0] = chars[0].upper()
for i in xrange(len(chars) -1):
    if chars[i] == ' ':
        chars[i+1] = chars[i+1].upper()
print ''.join(chars)
        
        
