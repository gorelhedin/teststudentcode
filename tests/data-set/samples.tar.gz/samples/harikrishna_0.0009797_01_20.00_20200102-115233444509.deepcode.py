

# Complete the solve function below.
def solve(s):
    return ' '.join(s[:1].upper() + s[1:] for s in s.split(' '))


print(solve('myword is here'))