def capitalize(string):
    a=string.split()
    for i in a:
        string=string.replace(i,i.capitalize())
        
    
    return(string)
    
    
   