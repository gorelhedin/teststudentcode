# Enter your code here. Read input from STDIN. Print output to STDOUT
ls = list(raw_input())
ls[0] = ls[0].upper()
#print [ls[ls.index(s)+1].upper() for s in ls if s==' ']
for i in range(len(ls)):
    if ls[i]==' ':
        ls[i+1] = ls[i+1].upper()

print ''.join(ls)