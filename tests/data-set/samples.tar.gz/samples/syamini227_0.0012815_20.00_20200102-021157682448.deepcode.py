

# Complete the solve function below.
def solve(s):
    lst = s.split(' ')
    lst1 = [lst[i].capitalize()for i in range(len(lst))]
    return ' '.join(lst1)

print(solve('myword is here'))