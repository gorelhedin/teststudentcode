# Enter your code here. Read input from STDIN. Print output to STDOUT
st = raw_input()
print st.title()