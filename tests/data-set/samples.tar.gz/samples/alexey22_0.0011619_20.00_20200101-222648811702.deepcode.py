def capitalize(s):
    t = True
    r = []
    for x in s:        
        if x != ' ': 
            if t and x.isalpha():
                x = x.upper()            
            t = False
        else:
            t = True
        r.append(x)
        
    return ''.join(r)
print(capitalize('myword is here'))