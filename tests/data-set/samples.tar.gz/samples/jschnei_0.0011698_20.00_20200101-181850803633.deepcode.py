import sys

line = [c for c in sys.stdin.readline()]
if line[0].isalpha():
    line[0] = line[0].upper()

for x in range(1, len(line)):
    if line[x-1]==' ':
        line[x] = line[x].upper()

print ''.join(line)