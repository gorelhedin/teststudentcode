

# Complete the solve function below.
def solve(s):
    s1=list(s)
    for i in range(0,len(s)):
        if(i==0):
            s1[i]=s1[i].upper()
        elif(s1[i]==" "):
            s1[i+1]=s1[i+1].upper()
    s2=""
    return s2.join(s1)


print(solve('myword is here'))