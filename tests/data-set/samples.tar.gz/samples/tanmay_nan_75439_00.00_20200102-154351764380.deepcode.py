# Complete the solve function below.
name=input()
if 0<len(name)<1000:
    list=name.split()
    s,x=list[:]
    A,B=s.capitalize(),x.capitalize()
    print(A,B)
    