

# Complete the solve function below.
def solve(s):
    str = s[0].upper()
    i = 1
    while i != len(s):
        if s[i] == ' ':
            i += 1
            str = str + ' ' + s[i].upper()
            i += 1
            continue
        if i == len(s):
            break
        str = str + s[i]
        i += 1
    return str




print(solve('myword is here'))