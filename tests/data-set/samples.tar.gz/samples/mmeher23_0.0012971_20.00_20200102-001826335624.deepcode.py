

# Complete the solve function below.
def solve(s):
    list1=list(s)
    for i in range(0,len(list1)):
        if i==0:
            list1[i]=list1[i].upper()
        elif list1[i]==" ":
            list1[i+1]=list1[i+1].upper()
    return ("".join(list1))



print(solve('myword is here'))