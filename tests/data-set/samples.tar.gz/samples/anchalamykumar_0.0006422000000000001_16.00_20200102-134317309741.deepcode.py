

# Complete the solve function below.
def solve(s):
    #s.title
    return s.title()


print(solve('myword is here'))