

# Complete the solve function below.
def solve(s):
    s= s.split(" ")
    s = " ".join(a.capitalize() for a in s)
    return s


print(solve('myword is here'))