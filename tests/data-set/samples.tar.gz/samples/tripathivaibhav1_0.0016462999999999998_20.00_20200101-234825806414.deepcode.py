

# Complete the solve function below.
def solve(s):
    result=''
    i=0
    while i<len(s):
        result+=s[i].upper()
        i+=1
        while i<len(s) and s[i]!=' ':
            result+=s[i]
            i+=1
        while i<len(s) and s[i]==' ':
            i+=1
            result+=' '        
    return result


print(solve('myword is here'))