# Enter your code here. Read input from STDIN. Print output to STDOUT
input = str(raw_input())
splittedData = input.split(" ")
lenght = len(splittedData)
output=""
count = 0;
for sData in splittedData:
    count += 1
    output = output + sData.capitalize()
    if count != lenght:
        output += " "

print output