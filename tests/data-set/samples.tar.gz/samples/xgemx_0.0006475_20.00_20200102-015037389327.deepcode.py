

# Complete the solve function below.
def solve(s):
    return ' '.join(x.capitalize() for x in s.split(' '))


print(solve('myword is here'))