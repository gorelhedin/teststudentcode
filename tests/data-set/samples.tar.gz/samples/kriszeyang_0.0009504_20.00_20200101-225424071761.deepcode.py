# Complete the solve function below.
def solve(s):
    list_string=s.split(' ')
    new_s=' '.join(word.capitalize() for word in list_string)
    return new_s
print(solve('myword is here'))