
# 1a 2b
# Complete the solve function below.
def solve(s):
    new_str = []
    for i in s.split(' '):
        new_str.append(i.capitalize())
    return ' '.join(new_str)
    

print(solve('myword is here'))