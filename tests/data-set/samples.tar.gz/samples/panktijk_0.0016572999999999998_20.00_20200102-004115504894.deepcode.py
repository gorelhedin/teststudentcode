

# Complete the solve function below.
def solve(s):
    return ' '.join([name.capitalize() for name in s.split(' ')])


print(solve('myword is here'))