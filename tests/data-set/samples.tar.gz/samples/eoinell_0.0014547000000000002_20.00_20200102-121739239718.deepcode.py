

# Complete the solve function below.
def solve(s):
    s = s.split(' ')
    s = [S.capitalize() for S in s]
    s = ' '.join(s)

    return s


print(solve('myword is here'))