

# Complete the solve function below.
def solve(s):
    A = []
    A = s.split()
    result = ''
    for i in range(0, len(A)-1):
        result += A[i].capitalize()
        result += ' '
    
    result += A[-1].capitalize()
    
    return result
   



print(solve('myword is here'))