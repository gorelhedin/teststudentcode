def capitalize(string):
    output = ''
    i = 0
    cap = True
    while i < len(string):
        char = string[i]
        output += char.upper() if cap else char
        cap = char == ' '
        i += 1
    return output
               


print(capitalize('myword is here'))