a=[word.capitalize() for word in raw_input().split(' ')]
print ' '.join(a)