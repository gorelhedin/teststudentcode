def capitalize(string):
    words = string.split(' ')
    answerList = [word.capitalize() for word in words]
    return ' '.join(answerList)

print(capitalize('myword is here'))