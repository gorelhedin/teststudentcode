

# Complete the solve function below.
def solve(s):
    ls = s.split(" ")
    for i in range(0,len(ls)):
        ls[i]=ls[i].capitalize()
    st = ""
    st = ' '.join(ls)

    return st


print(solve('myword is here'))