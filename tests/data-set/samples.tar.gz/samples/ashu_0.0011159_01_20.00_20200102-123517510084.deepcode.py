

# Complete the solve function below.
def solve(s):
    return(' '.join(i.capitalize() for i in s.split(' ')))
"""    
    c=s.split()
    l=len(c)
    return(c[0].capitalize()+" "+c[l-1].capitalize())
"""

print(solve('myword is here'))