
def solve(s) :
    s = s.split()
    return ' '.join([x.capitalize() for x in s])




