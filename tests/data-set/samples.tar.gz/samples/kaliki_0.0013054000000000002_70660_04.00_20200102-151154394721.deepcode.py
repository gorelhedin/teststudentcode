

# Complete the solve function below.
def solve(s):
    l=s.split(' ')
    m=[]
    s=''
    for i in l:
        li=list(i)
        t=li[0]
        t=t.upper()
        li[0]=t
        for j in li:
            s=s+j
        s+=' '    
    return s


print(solve('myword is here'))