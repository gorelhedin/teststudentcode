

# Complete the solve function below.
def solve(s):
    st = s.split(' ')
    rt = '' 
    for i in  st :
        rt=rt+' '+i.capitalize()
   ## print (rt.lstrip())
    return (rt.lstrip())


  


print(solve('myword is here'))