for i in input().split(" "):
    print(i.capitalize(), end=" ")
