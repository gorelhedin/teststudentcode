

# Complete the solve function below. 
def solve(s):
    s=s.split(" ")
    s1=[i.capitalize() for i in s]
    return " ".join(s1)

print(solve('myword is here'))