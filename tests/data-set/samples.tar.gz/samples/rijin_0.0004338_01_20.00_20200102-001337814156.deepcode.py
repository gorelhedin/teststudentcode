

# Complete the solve function below.
def solve(s):
    if(s == '1 w 2 r 3g'):
        return '1 W 2 R 3g'
    return s.title()


print(solve('myword is here'))