def capitalize(string):
    names = string.split(" ")
    
    capNames = []
    
    for n in names:
        if not n:
            capNames.append("")
        else:
            capNames.append( n[0].upper() + n[1:] )
    
    return " ".join(capNames)
print(capitalize('myword is here'))