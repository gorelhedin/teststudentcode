# Complete the solve function below.
def solve(s):
    k = s.split(" ")
    r = []
    for x in k:
        if x!='':       
            x = x[0].upper()+x[1:len(x)]
        r = r+[x]
    return " ".join(r)
print(solve('myword is here'))