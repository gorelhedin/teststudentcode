in_word=raw_input()
print in_word.title()