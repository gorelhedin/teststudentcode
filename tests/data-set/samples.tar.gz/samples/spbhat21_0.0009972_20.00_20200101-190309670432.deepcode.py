# Enter your code here. Read input from STDIN. Print output to STDOUT
str = raw_input()

for x in str[:].split():
	str = str.replace(x, x.capitalize())

print str