

# Complete the solve function below.
def solve(s):
    parts = s.split(' ')
    for i in range(0, len(parts)):
        if len(parts[i]) == 0:
            continue
        if parts[i][0].isalpha():
            parts[i] = parts[i][0].upper() + parts[i][1:]
    return ' '.join(parts)



print(solve('myword is here'))