

# Complete the solve function below.
def solve(s):
    b=s.split(" ")
    

    
    return ' '.join(i.capitalize() for i in b)
        #if s[i]=" ":
            #return (s[:i]+s[i+1].capitalize()+s[i+2:])

    #return (s.capitalize())


print(solve('myword is here'))