# Enter your code here. Read input from STDIN. Print output to STDOUT
S = raw_input().split(" ")
for word in S:
    print word.capitalize(),