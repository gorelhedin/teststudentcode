# Complete the solve function below.
def solve(s):
    ans=""
    for i in range(0,len(s)):
        if i == 0 :
            ans =  s[0].capitalize()
        else:
            if s[i-1] == ' ':
                ans = ans+s[i].capitalize()
            else:
                ans = ans+s[i]
    return ans
        
            
            
       
print(solve('myword is here'))