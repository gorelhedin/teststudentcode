

# Complete the solve function below.
def solve(s):
    s = list(s)
    new = True
    for i in range(len(s)):
        if new and s[i] != " ":
            s[i] = s[i].upper()
            new = False
        elif s[i] == " ":
            new = True
    
    return "".join(s)




print(solve('myword is here'))