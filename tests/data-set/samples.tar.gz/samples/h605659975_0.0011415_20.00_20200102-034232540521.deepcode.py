

# Complete the solve function below.
def solve(s):
    List = s.split()
    for i in List:
        s = s.replace(i, i.capitalize())

    return s


print(solve('myword is here'))