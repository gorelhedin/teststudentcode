

# Complete the solve function below.
def solve(s):
    L = []
    L = s.split(" ")
    st = ""
    for i in range(len(L)):
        P = []
        P = list(L[i])
        print(P[0])
        P[0] = P[0].upper()
        print(P[0])
        jk = ""
        jk = jk.join(P)
        st+=jk
        if i!=len(L)-1 :
            st+=" "
    return st

print(solve('myword is here'))