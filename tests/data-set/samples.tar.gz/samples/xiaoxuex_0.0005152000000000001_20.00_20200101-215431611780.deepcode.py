def capitalize(string):
    l = list(string)
    l[0] = string[0].upper()
    for i in range(len(string)-1):
        if string[i] == ' ':
            l[i+1] = string[i+1].upper()
    return(''.join(l))
print(capitalize('myword is here'))