a=raw_input().split(' ')
for i in xrange(len(a)):
    a[i]=a[i].capitalize()
print ' '.join(a)