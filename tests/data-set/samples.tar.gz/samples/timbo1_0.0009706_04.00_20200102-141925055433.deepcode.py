def capitalize(string):
    words = string.split()
    new_words = []
    for word in words:
        if word[0].isalpha():
            new_words.append(word.title())
        else:
            new_words.append(word)
    return " ".join(new_words)


print(capitalize('myword is here'))