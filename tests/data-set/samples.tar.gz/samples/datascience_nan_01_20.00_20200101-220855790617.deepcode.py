def capitalize(string):
    #return ' '.join(ss.capitalize() for ss in string.split())

    for s in string.strip().split():
        string = string.replace(s, s.capitalize())
        
    return string