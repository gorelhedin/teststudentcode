

# Complete the solve function below.
def solve(s):
    s = s.split(" ")
    texto = ""
    for i in range(len(s)):
        s[i] = s[i].capitalize()
    s = ' '.join(s)
    return s


print(solve('myword is here'))