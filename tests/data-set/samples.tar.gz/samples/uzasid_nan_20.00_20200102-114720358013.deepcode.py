

# Complete the solve function below.
def solve(s):
    s=s
    t=list(s)
    l_t=len(t)
#l_t
    i=0
    if(t[0]!=" "):
        if(ord(t[0])>96 and ord(t[0])<127):
            t[0]=chr(ord(t[0])-32)
    while(i<(l_t-1)):
        if(t[i]==" " and (t[i+1]!=" ")):
            if(ord(t[i+1])>96 and ord(t[i+1])<127):
                t[i+1]=chr(ord(t[i+1])-32)
                print(t[i+1])
        
        i+=1
    i=0
    final=""
    while(i<l_t):
        final=final+t[i]
        i+=1
    return final


print(solve('myword is here'))