

# Complete the solve function below.
def solve(s):
        L = []
        l = s.split(' ')
        for i in l:
            L.append(i.capitalize())
        return ' '.join(L)


print(solve('myword is here'))