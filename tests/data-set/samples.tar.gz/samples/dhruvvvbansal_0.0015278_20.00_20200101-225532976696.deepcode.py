# Complete the solve function below.
def solve(s):
    #string=input()
    list2=[]
    if len(s)>0 and len(s)<1000:
        list1=s.split(" ")
        for item in list1:
            item1=item.capitalize()
            list2.append(item1)
        string = " ".join(list2)
    return string
print(solve('myword is here'))