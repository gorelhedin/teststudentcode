

# Complete the solve function below.
'''def solve(s):
  list1 = s.split()
  n = len(list1)
  for i in range(n):
    list1[i] = list1[i][0].upper() + list1[i][1:]
  return ' '.join(list1)
'''
def solve(s):
  for x in s.split():
   # s = ' '.join[x for x = x.capitalize()]
    s = s.replace(x, x.capitalize())
  return s

