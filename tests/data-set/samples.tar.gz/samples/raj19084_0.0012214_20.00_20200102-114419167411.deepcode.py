

# Complete the solve function below.

def solve(s):
    i=s[0].capitalize()
    for x in range(1,len(s)):
        if s[x]==' ' and s[x+1]!=' ':
            i=i+s[x]+s[x+1].capitalize()
        elif s[x]!=' ' and s[x-1]!=' ':
            i=i+s[x]
        elif s[x]==' ' and s[x+1]==' ':
            i=i+s[x]
    return i

print(solve('myword is here'))