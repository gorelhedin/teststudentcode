

# Complete the solve function below.
def solve(s):
    l3 = []
    for index, c in enumerate(s[1:], 1):
        if s[index-1] == ' ':
            l3.append(c.upper())
        else:
            l3.append(c)

    return s[0].upper() + ''.join(l3)
    

print(solve('myword is here'))