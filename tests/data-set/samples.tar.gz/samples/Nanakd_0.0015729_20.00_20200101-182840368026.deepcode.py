# Enter your code here. Read input from STDIN. Print output to STDOUT
s=raw_input()
for i in s[:].split():
    s=s.replace(i,i.capitalize())
print s    