s=raw_input()
l=len(s)
n=""
j=0
for i in range(0,l):
    if(s[i]==' '):
        n=n+s[j:i].capitalize()+" "
        j=i+1
n=n+s[j:i+1].capitalize()
print n