# Enter your code here. Read input from STDIN. Print output to STDOUT
inputString = raw_input()
print ' '.join(map(str.capitalize, inputString.split(' ')))