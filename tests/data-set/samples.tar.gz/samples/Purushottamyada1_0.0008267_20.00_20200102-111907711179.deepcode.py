

# Complete the solve function below.
def solve(s):
    '''lst=s.split()
    strr=lst[0].capitalize()
    for i in range(1,len(lst)):
        strr+=" "+lst[i].capitalize()
    return strr'''
    l=s.split(" ")
    a = [i.capitalize() for i in l]       
    return " ".join(a)


print(solve('myword is here'))