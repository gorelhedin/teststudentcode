def capitalize(string):
    newString = ""
    lastChar = " "
    for character in string:
        if(lastChar == " "):
            newString += character.upper()
        else:
            newString += character
        lastChar = character
    return newString
print(capitalize('myword is here'))