def capitalize(string):
    string = list(string)
    L = []
    for i in range(len(string)):
        if i == 0:
            L.append(string[i].upper())
        if i != 0 and string[i-1] != ' ':
            L.append(string[i])
        if i != 0 and string[i-1] == ' ':
            L.append(string[i].upper())
    a = ''.join(L)
    return a
print(capitalize('myword is here'))