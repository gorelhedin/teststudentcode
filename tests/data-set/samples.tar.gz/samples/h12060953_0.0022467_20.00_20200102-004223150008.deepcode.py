

# Complete the solve function below.
def solve(s):
    s=s.split(" ")
    fin=[]
    for i in s:
        bob=i.capitalize()
        fin.append(bob)
    return (" ".join(fin))
        



print(solve('myword is here'))