

# Complete the solve function below.
def solve(s):
    p=s
    for i in p[:].split() :
        p=p.replace(i,str.capitalize(i))
    return(p)



print(solve('myword is here'))