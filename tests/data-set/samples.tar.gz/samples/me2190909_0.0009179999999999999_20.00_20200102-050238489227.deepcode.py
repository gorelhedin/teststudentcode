

# Complete the solve function below.
def solve(s):
  l=s.split(" ")
  for i in range(len(l)):
      l[i]=l[i].capitalize()
  a=""
  for i in range(len(l)):
      a=a+l[i]
      if i!=len(l)-1:
          a=a+" "
  return a            



















print(solve('myword is here'))