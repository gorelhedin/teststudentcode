

# Complete the solve function below.
def solve(s):

    string = s.split(' ') 
    return(' '.join((word.capitalize() for word in string))) 
   
        
        
        


print(solve('myword is here'))