def capitalize(string):
    length = len(string)
    i = 0
    while i < length:
        if i == 0: 
            if ord(string[i]) >= 97 and ord(string[i]) <= 127:
                final = chr(ord(string[i]) - 32)
            else: 
                final = string[i]
        else:
            if ord(string[i]) == 32:
                #final = final + string[i]
                while string[i] == ' ':
                    final = final + string[i]
                    i = i  + 1
                #final = final + string[i]
                if ord(string[i]) >= 97 and ord(string[i]) <= 127:
                    final = final + chr((ord(string[i]) - 32))
                else:
                    final = final + string[i]
                
            else:
                final = final + string[i]
        i = i + 1
    return final


print(capitalize('myword is here'))