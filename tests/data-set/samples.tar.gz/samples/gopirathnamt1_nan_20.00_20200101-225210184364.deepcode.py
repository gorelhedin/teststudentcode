# Complete the solve function below.
def solve(s):
    s=s.replace(' ',' * ')
    x=s.split()
    t=''
    for i in x:
        print i
        if(i.isalpha() or i.isdigit()):
            t=t+i.title()
        elif(i.isalnum() ):
            t=t+i
        elif (i =='*'):
            t=t+' '
        else:
            t=t+i.title()
    return t
print(solve('myword is here'))