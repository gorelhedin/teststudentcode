

# Complete the solve function below.
def solve(s):
    namelist = s.split()
    return ' '.join(list(map(lambda x:x.capitalize(),namelist)))


print(solve('myword is here'))