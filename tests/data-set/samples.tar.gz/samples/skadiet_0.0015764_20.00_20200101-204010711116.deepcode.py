def capitalize(string):
    ret = ''
    for i in string.split(' '):
        hasCapitalized = False
        for j in range(len(i)):
            if hasCapitalized == False:
                if i[j].islower():
                    hasCapitalized=True
                    ret += i[j].upper()
                    continue
                else:
                    hasCapitalized = True
            ret+=i[j]
        ret += ' '
        
    return ret 


print(capitalize('myword is here'))