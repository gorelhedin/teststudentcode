
import string
# Complete the solve function below.
def solve(s):
    return string.capwords(s, ' ')


print(solve('myword is here'))