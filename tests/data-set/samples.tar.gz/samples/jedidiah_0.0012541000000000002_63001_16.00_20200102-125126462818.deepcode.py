def capitalize(string):
    
    if(0<len(string)<1000):
        string =string.title()
        return string
print(capitalize('myword is here'))