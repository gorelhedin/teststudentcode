def capitalize(string):
    str = string.title()
    return str
   
print(capitalize('myword is here'))