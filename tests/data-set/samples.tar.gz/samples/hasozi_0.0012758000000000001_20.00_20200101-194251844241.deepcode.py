def capitalize(string):
    first = True
    new_s = ""
    for c in string:
        if first and c.isalpha():
            new_s += c.upper()
        else:
            new_s += c
        if c == ' ':
            first = True
        else:
            first = False
    return new_s
print(capitalize('myword is here'))