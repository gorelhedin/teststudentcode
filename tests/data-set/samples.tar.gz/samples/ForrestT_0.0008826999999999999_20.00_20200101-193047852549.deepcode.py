S = raw_input()
L = [word.capitalize() for word in S.split(' ')]
print(' '.join(L))