

# Complete the solve function below.
def solve(s):
    l=s.split(" ")
    return ' '.join([s.capitalize() for s in l])




print(solve('myword is here'))