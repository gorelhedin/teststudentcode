newlist = []

# Complete the solve function below.
def solve(s):
    for i in s:
        newlist.append(i)

    return newlist
print(solve('myword is here'))