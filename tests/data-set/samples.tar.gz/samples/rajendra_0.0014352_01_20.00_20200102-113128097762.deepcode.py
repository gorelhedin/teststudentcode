

# Complete the solve function below.
def solve(s):
    #return s.title()
    for word in s.split():
        s = s.replace(word, word.capitalize())
    return s



print(solve('myword is here'))