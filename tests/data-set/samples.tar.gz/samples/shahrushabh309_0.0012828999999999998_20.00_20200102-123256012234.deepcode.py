

# Complete the solve function below.
def solve(s):
    if len(s) > 0 and len(s)< 1000:
        name = s.split(' ')
        return ' '.join(w.capitalize() for w in name)



print(solve('myword is here'))