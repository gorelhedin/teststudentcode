# Complete the solve function below.
import string

def solve(s):
    l = [elem.capitalize() for elem in s.split()]

    for elem in l:
        s = s.replace(elem.lower(),elem)
    
    return(s)

print(solve('myword is here'))