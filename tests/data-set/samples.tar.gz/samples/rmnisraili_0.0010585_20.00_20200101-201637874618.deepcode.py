def capitalize(string):
    flag = True
    mlist = list(string)
    s = ''
    for item in mlist:
        if flag:
            s += item.upper()
            flag = False
        else:
            s += item
        if item == ' ':
            flag = True
    return s
        
            
        
print(capitalize('myword is here'))