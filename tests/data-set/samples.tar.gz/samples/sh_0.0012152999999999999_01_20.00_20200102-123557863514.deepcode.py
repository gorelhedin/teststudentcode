

# Complete the solve function below.
import string

def solve(s):
    m = s.split(' ')
    for i in range(len(m)):
        m[i]=m[i].capitalize()
    return (' ').join(m)
    

print(solve('myword is here'))