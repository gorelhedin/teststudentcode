

# Complete the solve function below.
def solve(s):
    l = s.split(' ')

    return ' '.join([w.capitalize() for w in l])




print(solve('myword is here'))