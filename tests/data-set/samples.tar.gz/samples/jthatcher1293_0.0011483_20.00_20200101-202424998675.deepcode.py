def capitalize(string):
    newString = string.capitalize()
    for num in range(1, len(newString)):
        if newString[num-1] == ' ':
            newString = newString[:num] + newString[num].upper() + newString[num+1:]
    return newString
print(capitalize('myword is here'))